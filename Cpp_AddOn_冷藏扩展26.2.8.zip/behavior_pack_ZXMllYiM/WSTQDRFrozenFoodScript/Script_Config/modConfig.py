# -*- coding: utf-8 -*-

#不能精准采集的方块
NoMiningSilkTouchDict = {
    #冰棍
    "wstqdr:classic_popsicle_block",
    "wstqdr:apple_popsicle_block",
    "wstqdr:banana_popsicle_block",
    "wstqdr:blue_berry_popsicle_block",
    "wstqdr:chocolate_popsicle_block",
    "wstqdr:chorus_fruit_popsicle_block",
    "wstqdr:corn_popsicle_block",
    "wstqdr:cream_popsicle_block",
    "wstqdr:glow_berry_popsicle_block",
    "wstqdr:honey_popsicle_block",
    "wstqdr:strawberry_popsicle_block",
    "wstqdr:sweet_berry_popsicle_block",
    "wstqdr:tomato_popsicle_block",

    #冰淇淋筒
    "wstqdr:icecreamcone_block",
    "wstqdr:apple_icecreamcone_block",
    "wstqdr:banana_icecreamcone_block",
    "wstqdr:blue_berry_icecreamcone_block",
    "wstqdr:chocolate_icecreamcone_block",
    "wstqdr:chorus_fruit_icecreamcone_block",
    "wstqdr:corn_icecreamcone_block",
    "wstqdr:cream_icecreamcone_block",
    "wstqdr:glistering_melon_icecreamcone_block",
    "wstqdr:glow_berry_icecreamcone_block",
    "wstqdr:melon_icecreamcone_block",
    "wstqdr:strawberry_icecreamcone_block",
    "wstqdr:sweet_berry_icecreamcone_block",
    "wstqdr:tomato_icecreamcone_block",
    #冰淇淋杯
    "wstqdr:icecreamcup_block",
    "wstqdr:apple_icecreamcup_block",
    "wstqdr:banana_icecreamcup_block",
    "wstqdr:blue_berry_icecreamcup_block",
    "wstqdr:chocolate_icecreamcup_block",
    "wstqdr:chorus_fruit_icecreamcup_block",
    "wstqdr:corn_icecreamcup_block",
    "wstqdr:cream_icecreamcup_block",
    "wstqdr:glistering_melon_icecreamcup_block",
    "wstqdr:glow_berry_icecreamcup_block",
    "wstqdr:melon_icecreamcup_block",
    "wstqdr:strawberry_icecreamcup_block",
    "wstqdr:sweet_berry_icecreamcup_block",
    "wstqdr:tomato_icecreamcup_block",
    #雪泥大王
    "wstqdr:snow_smoothie_block",
    "wstqdr:apple_smoothie_block",
    "wstqdr:banana_smoothie_block",
    "wstqdr:blue_berry_smoothie_block",
    "wstqdr:chocolate_carrot_smoothie_block",
    "wstqdr:chocolate_smoothie_block",
    "wstqdr:chorus_fruit_smoothie_block",
    "wstqdr:corn_smoothie_block",
    "wstqdr:cream_smoothie_block",
    "wstqdr:glistering_melon_smoothie_block",
    "wstqdr:glow_berry_smoothie_block",
    "wstqdr:grape_smoothie_block",
    "wstqdr:honey_smoothie_block",
    "wstqdr:melon_smoothie_block",
    "wstqdr:strawberry_smoothie_block",
    "wstqdr:sweet_berry_smoothie_block",
    "wstqdr:tomato_smoothie_block"
}

#可被水冲成掉落物的方块
CanWaterDestoryWSTQDRFrozenBlocks = {
    #冰棍
    "wstqdr:classic_popsicle_block":{},
    "wstqdr:apple_popsicle_block":{},
    "wstqdr:banana_popsicle_block":{},
    "wstqdr:blue_berry_popsicle_block":{},
    "wstqdr:chocolate_popsicle_block":{},
    "wstqdr:chorus_fruit_popsicle_block":{},
    "wstqdr:corn_popsicle_block":{},
    "wstqdr:cream_popsicle_block":{},
    "wstqdr:glow_berry_popsicle_block":{},
    "wstqdr:honey_popsicle_block":{},
    "wstqdr:strawberry_popsicle_block":{},
    "wstqdr:sweet_berry_popsicle_block":{},
    "wstqdr:tomato_popsicle_block":{},

    #冰淇淋筒
    "wstqdr:icecreamcone_block":{},
    "wstqdr:apple_icecreamcone_block":{},
    "wstqdr:banana_icecreamcone_block":{},
    "wstqdr:blue_berry_icecreamcone_block":{},
    "wstqdr:chocolate_icecreamcone_block":{},
    "wstqdr:chorus_fruit_icecreamcone_block":{},
    "wstqdr:corn_icecreamcone_block":{},
    "wstqdr:cream_icecreamcone_block":{},
    "wstqdr:glistering_melon_icecreamcone_block":{},
    "wstqdr:glow_berry_icecreamcone_block":{},
    "wstqdr:melon_icecreamcone_block":{},
    "wstqdr:strawberry_icecreamcone_block":{},
    "wstqdr:sweet_berry_icecreamcone_block":{},
    "wstqdr:tomato_icecreamcone_block":{},
    #冰淇淋杯
    "wstqdr:icecreamcup_block":{"DropList":[{"newItemName": "minecraft:glass_bottle","count": 1}]},
    "wstqdr:apple_icecreamcup_block":{"DropList":[{"newItemName": "minecraft:glass_bottle","count": 1}]},
    "wstqdr:banana_icecreamcup_block":{"DropList":[{"newItemName": "minecraft:glass_bottle","count": 1}]},
    "wstqdr:blue_berry_icecreamcup_block":{"DropList":[{"newItemName": "minecraft:glass_bottle","count": 1}]},
    "wstqdr:chocolate_icecreamcup_block":{"DropList":[{"newItemName": "minecraft:glass_bottle","count": 1}]},
    "wstqdr:chorus_fruit_icecreamcup_block":{"DropList":[{"newItemName": "minecraft:glass_bottle","count": 1}]},
    "wstqdr:corn_icecreamcup_block":{"DropList":[{"newItemName": "minecraft:glass_bottle","count": 1}]},
    "wstqdr:cream_icecreamcup_block":{"DropList":[{"newItemName": "minecraft:glass_bottle","count": 1}]},
    "wstqdr:glistering_melon_icecreamcup_block":{"DropList":[{"newItemName": "minecraft:glass_bottle","count": 1}]},
    "wstqdr:glow_berry_icecreamcup_block":{"DropList":[{"newItemName": "minecraft:glass_bottle","count": 1}]},
    "wstqdr:melon_icecreamcup_block":{"DropList":[{"newItemName": "minecraft:glass_bottle","count": 1}]},
    "wstqdr:strawberry_icecreamcup_block":{"DropList":[{"newItemName": "minecraft:glass_bottle","count": 1}]},
    "wstqdr:sweet_berry_icecreamcup_block":{"DropList":[{"newItemName": "minecraft:glass_bottle","count": 1}]},
    "wstqdr:tomato_icecreamcup_block":{"DropList":[{"newItemName": "minecraft:glass_bottle","count": 1}]},
    #雪泥大王
    "wstqdr:snow_smoothie_block":{"DropList":[{"newItemName": "minecraft:glass_bottle","count": 1}]},
    "wstqdr:apple_smoothie_block":{"DropList":[{"newItemName": "minecraft:glass_bottle","count": 1}]},
    "wstqdr:banana_smoothie_block":{"DropList":[{"newItemName": "minecraft:glass_bottle","count": 1}]},
    "wstqdr:blue_berry_smoothie_block":{"DropList":[{"newItemName": "minecraft:glass_bottle","count": 1}]},
    "wstqdr:chocolate_carrot_smoothie_block":{"DropList":[{"newItemName": "minecraft:glass_bottle","count": 1}]},
    "wstqdr:chocolate_smoothie_block":{"DropList":[{"newItemName": "minecraft:glass_bottle","count": 1}]},
    "wstqdr:chorus_fruit_smoothie_block":{"DropList":[{"newItemName": "minecraft:glass_bottle","count": 1}]},
    "wstqdr:corn_smoothie_block":{"DropList":[{"newItemName": "minecraft:glass_bottle","count": 1}]},
    "wstqdr:cream_smoothie_block":{"DropList":[{"newItemName": "minecraft:glass_bottle","count": 1}]},
    "wstqdr:glistering_melon_smoothie_block":{"DropList":[{"newItemName": "minecraft:glass_bottle","count": 1}]},
    "wstqdr:glow_berry_smoothie_block":{"DropList":[{"newItemName": "minecraft:glass_bottle","count": 1}]},
    "wstqdr:grape_smoothie_block":{"DropList":[{"newItemName": "minecraft:glass_bottle","count": 1}]},
    "wstqdr:honey_smoothie_block":{"DropList":[{"newItemName": "minecraft:glass_bottle","count": 1}]},
    "wstqdr:melon_smoothie_block":{"DropList":[{"newItemName": "minecraft:glass_bottle","count": 1}]},
    "wstqdr:strawberry_smoothie_block":{"DropList":[{"newItemName": "minecraft:glass_bottle","count": 1}]},
    "wstqdr:sweet_berry_smoothie_block":{"DropList":[{"newItemName": "minecraft:glass_bottle","count": 1}]},
    "wstqdr:tomato_smoothie_block":{"DropList":[{"newItemName": "minecraft:glass_bottle","count": 1}]}
}

#可放置和拿起的
CanPlatedItems = {
    #冰棍
    ("wstqdr:classic_popsicle","wstqdr:classic_popsicle_block"):{"Stackable":{"stageMin":0,"stageMax":3},"DropList":{0:[{"newItemName": "wstqdr:classic_popsicle","count": 1}],1:[{"newItemName": "wstqdr:classic_popsicle","count": 2}],2:[{"newItemName": "wstqdr:classic_popsicle","count": 3}],3:[{"newItemName": "wstqdr:classic_popsicle","count": 4}]},"sound":{"name":"dig.stone","volume":(1.0,1.0),"pitch":(0.8,1.0)}},
    ("wstqdr:apple_popsicle","wstqdr:apple_popsicle_block"):{"Stackable":{"stageMin":0,"stageMax":3},"DropList":{0:[{"newItemName": "wstqdr:apple_popsicle","count": 1}],1:[{"newItemName": "wstqdr:apple_popsicle","count": 2}],2:[{"newItemName": "wstqdr:apple_popsicle","count": 3}],3:[{"newItemName": "wstqdr:apple_popsicle","count": 4}]},"sound":{"name":"dig.stone","volume":(1.0,1.0),"pitch":(0.8,1.0)}},
    ("wstqdr:banana_popsicle","wstqdr:banana_popsicle_block"):{"Stackable":{"stageMin":0,"stageMax":3},"DropList":{0:[{"newItemName": "wstqdr:banana_popsicle","count": 1}],1:[{"newItemName": "wstqdr:banana_popsicle","count": 2}],2:[{"newItemName": "wstqdr:banana_popsicle","count": 3}],3:[{"newItemName": "wstqdr:banana_popsicle","count": 4}]},"sound":{"name":"dig.stone","volume":(1.0,1.0),"pitch":(0.8,1.0)}},
    ("wstqdr:blue_berry_popsicle","wstqdr:blue_berry_popsicle_block"):{"Stackable":{"stageMin":0,"stageMax":3},"DropList":{0:[{"newItemName": "wstqdr:blue_berry_popsicle","count": 1}],1:[{"newItemName": "wstqdr:blue_berry_popsicle","count": 2}],2:[{"newItemName": "wstqdr:blue_berry_popsicle","count": 3}],3:[{"newItemName": "wstqdr:blue_berry_popsicle","count": 4}]},"sound":{"name":"dig.stone","volume":(1.0,1.0),"pitch":(0.8,1.0)}},
    ("wstqdr:chocolate_popsicle","wstqdr:chocolate_popsicle_block"):{"Stackable":{"stageMin":0,"stageMax":3},"DropList":{0:[{"newItemName": "wstqdr:chocolate_popsicle","count": 1}],1:[{"newItemName": "wstqdr:chocolate_popsicle","count": 2}],2:[{"newItemName": "wstqdr:chocolate_popsicle","count": 3}],3:[{"newItemName": "wstqdr:chocolate_popsicle","count": 4}]},"sound":{"name":"dig.stone","volume":(1.0,1.0),"pitch":(0.8,1.0)}},
    ("wstqdr:chorus_fruit_popsicle","wstqdr:chorus_fruit_popsicle_block"):{"Stackable":{"stageMin":0,"stageMax":3},"DropList":{0:[{"newItemName": "wstqdr:chorus_fruit_popsicle","count": 1}],1:[{"newItemName": "wstqdr:chorus_fruit_popsicle","count": 2}],2:[{"newItemName": "wstqdr:chorus_fruit_popsicle","count": 3}],3:[{"newItemName": "wstqdr:chorus_fruit_popsicle","count": 4}]},"sound":{"name":"dig.stone","volume":(1.0,1.0),"pitch":(0.8,1.0)}},
    ("wstqdr:corn_popsicle","wstqdr:corn_popsicle_block"):{"Stackable":{"stageMin":0,"stageMax":3},"DropList":{0:[{"newItemName": "wstqdr:corn_popsicle","count": 1}],1:[{"newItemName": "wstqdr:corn_popsicle","count": 2}],2:[{"newItemName": "wstqdr:corn_popsicle","count": 3}],3:[{"newItemName": "wstqdr:corn_popsicle","count": 4}]},"sound":{"name":"dig.stone","volume":(1.0,1.0),"pitch":(0.8,1.0)}},
    ("wstqdr:cream_popsicle","wstqdr:cream_popsicle_block"):{"Stackable":{"stageMin":0,"stageMax":3},"DropList":{0:[{"newItemName": "wstqdr:cream_popsicle","count": 1}],1:[{"newItemName": "wstqdr:cream_popsicle","count": 2}],2:[{"newItemName": "wstqdr:cream_popsicle","count": 3}],3:[{"newItemName": "wstqdr:cream_popsicle","count": 4}]},"sound":{"name":"dig.stone","volume":(1.0,1.0),"pitch":(0.8,1.0)}},
    ("wstqdr:glow_berry_popsicle","wstqdr:glow_berry_popsicle_block"):{"Stackable":{"stageMin":0,"stageMax":3},"DropList":{0:[{"newItemName": "wstqdr:glow_berry_popsicle","count": 1}],1:[{"newItemName": "wstqdr:glow_berry_popsicle","count": 2}],2:[{"newItemName": "wstqdr:glow_berry_popsicle","count": 3}],3:[{"newItemName": "wstqdr:glow_berry_popsicle","count": 4}]},"sound":{"name":"dig.stone","volume":(1.0,1.0),"pitch":(0.8,1.0)}},
    ("wstqdr:honey_popsicle","wstqdr:honey_popsicle_block"):{"Stackable":{"stageMin":0,"stageMax":3},"DropList":{0:[{"newItemName": "wstqdr:honey_popsicle","count": 1}],1:[{"newItemName": "wstqdr:honey_popsicle","count": 2}],2:[{"newItemName": "wstqdr:honey_popsicle","count": 3}],3:[{"newItemName": "wstqdr:honey_popsicle","count": 4}]},"sound":{"name":"dig.stone","volume":(1.0,1.0),"pitch":(0.8,1.0)}},
    ("wstqdr:strawberry_popsicle","wstqdr:strawberry_popsicle_block"):{"Stackable":{"stageMin":0,"stageMax":3},"DropList":{0:[{"newItemName": "wstqdr:strawberry_popsicle","count": 1}],1:[{"newItemName": "wstqdr:strawberry_popsicle","count": 2}],2:[{"newItemName": "wstqdr:strawberry_popsicle","count": 3}],3:[{"newItemName": "wstqdr:strawberry_popsicle","count": 4}]},"sound":{"name":"dig.stone","volume":(1.0,1.0),"pitch":(0.8,1.0)}},
    ("wstqdr:sweet_berry_popsicle","wstqdr:sweet_berry_popsicle_block"):{"Stackable":{"stageMin":0,"stageMax":3},"DropList":{0:[{"newItemName": "wstqdr:sweet_berry_popsicle","count": 1}],1:[{"newItemName": "wstqdr:sweet_berry_popsicle","count": 2}],2:[{"newItemName": "wstqdr:sweet_berry_popsicle","count": 3}],3:[{"newItemName": "wstqdr:sweet_berry_popsicle","count": 4}]},"sound":{"name":"dig.stone","volume":(1.0,1.0),"pitch":(0.8,1.0)}},
    ("wstqdr:tomato_popsicle","wstqdr:tomato_popsicle_block"):{"Stackable":{"stageMin":0,"stageMax":3},"DropList":{0:[{"newItemName": "wstqdr:tomato_popsicle","count": 1}],1:[{"newItemName": "wstqdr:tomato_popsicle","count": 2}],2:[{"newItemName": "wstqdr:tomato_popsicle","count": 3}],3:[{"newItemName": "wstqdr:tomato_popsicle","count": 4}]},"sound":{"name":"dig.stone","volume":(1.0,1.0),"pitch":(0.8,1.0)}},
    #冰淇淋筒
    ("wstqdr:icecreamcone","wstqdr:icecreamcone_block"):{"Stackable":{"stageMin":0,"stageMax":3},"DropList":{0:[{"newItemName": "wstqdr:icecreamcone","count": 1}],1:[{"newItemName": "wstqdr:icecreamcone","count": 2}],2:[{"newItemName": "wstqdr:icecreamcone","count": 3}],3:[{"newItemName": "wstqdr:icecreamcone","count": 4}]},"sound":{"name":"dig.cloth","volume":(0.8,1.0),"pitch":(0.8,1.0)}},
    ("wstqdr:apple_icecreamcone","wstqdr:apple_icecreamcone_block"):{"Stackable":{"stageMin":0,"stageMax":3},"DropList":{0:[{"newItemName": "wstqdr:apple_icecreamcone","count": 1}],1:[{"newItemName": "wstqdr:apple_icecreamcone","count": 2}],2:[{"newItemName": "wstqdr:apple_icecreamcone","count": 3}],3:[{"newItemName": "wstqdr:apple_icecreamcone","count": 4}]},"sound":{"name":"dig.cloth","volume":(0.8,1.0),"pitch":(0.8,1.0)}},
    ("wstqdr:banana_icecreamcone","wstqdr:banana_icecreamcone_block"):{"Stackable":{"stageMin":0,"stageMax":3},"DropList":{0:[{"newItemName": "wstqdr:banana_icecreamcone","count": 1}],1:[{"newItemName": "wstqdr:banana_icecreamcone","count": 2}],2:[{"newItemName": "wstqdr:banana_icecreamcone","count": 3}],3:[{"newItemName": "wstqdr:banana_icecreamcone","count": 4}]},"sound":{"name":"dig.cloth","volume":(0.8,1.0),"pitch":(0.8,1.0)}},
    ("wstqdr:blue_berry_icecreamcone","wstqdr:blue_berry_icecreamcone_block"):{"Stackable":{"stageMin":0,"stageMax":3},"DropList":{0:[{"newItemName": "wstqdr:blue_berry_icecreamcone","count": 1}],1:[{"newItemName": "wstqdr:blue_berry_icecreamcone","count": 2}],2:[{"newItemName": "wstqdr:blue_berry_icecreamcone","count": 3}],3:[{"newItemName": "wstqdr:blue_berry_icecreamcone","count": 4}]},"sound":{"name":"dig.cloth","volume":(0.8,1.0),"pitch":(0.8,1.0)}},
    ("wstqdr:chocolate_icecreamcone","wstqdr:chocolate_icecreamcone_block"):{"Stackable":{"stageMin":0,"stageMax":3},"DropList":{0:[{"newItemName": "wstqdr:chocolate_icecreamcone","count": 1}],1:[{"newItemName": "wstqdr:chocolate_icecreamcone","count": 2}],2:[{"newItemName": "wstqdr:chocolate_icecreamcone","count": 3}],3:[{"newItemName": "wstqdr:chocolate_icecreamcone","count": 4}]},"sound":{"name":"dig.cloth","volume":(0.8,1.0),"pitch":(0.8,1.0)}},
    ("wstqdr:chorus_fruit_icecreamcone","wstqdr:chorus_fruit_icecreamcone_block"):{"Stackable":{"stageMin":0,"stageMax":3},"DropList":{0:[{"newItemName": "wstqdr:chorus_fruit_icecreamcone","count": 1}],1:[{"newItemName": "wstqdr:chorus_fruit_icecreamcone","count": 2}],2:[{"newItemName": "wstqdr:chorus_fruit_icecreamcone","count": 3}],3:[{"newItemName": "wstqdr:chorus_fruit_icecreamcone","count": 4}]},"sound":{"name":"dig.cloth","volume":(0.8,1.0),"pitch":(0.8,1.0)}},
    ("wstqdr:corn_icecreamcone","wstqdr:corn_icecreamcone_block"):{"Stackable":{"stageMin":0,"stageMax":3},"DropList":{0:[{"newItemName": "wstqdr:corn_icecreamcone","count": 1}],1:[{"newItemName": "wstqdr:corn_icecreamcone","count": 2}],2:[{"newItemName": "wstqdr:corn_icecreamcone","count": 3}],3:[{"newItemName": "wstqdr:corn_icecreamcone","count": 4}]},"sound":{"name":"dig.cloth","volume":(0.8,1.0),"pitch":(0.8,1.0)}},
    ("wstqdr:cream_icecreamcone","wstqdr:cream_icecreamcone_block"):{"Stackable":{"stageMin":0,"stageMax":3},"DropList":{0:[{"newItemName": "wstqdr:cream_icecreamcone","count": 1}],1:[{"newItemName": "wstqdr:cream_icecreamcone","count": 2}],2:[{"newItemName": "wstqdr:cream_icecreamcone","count": 3}],3:[{"newItemName": "wstqdr:cream_icecreamcone","count": 4}]},"sound":{"name":"dig.cloth","volume":(0.8,1.0),"pitch":(0.8,1.0)}},
    ("wstqdr:glistering_melon_icecreamcone","wstqdr:glistering_melon_icecreamcone_block"):{"Stackable":{"stageMin":0,"stageMax":3},"DropList":{0:[{"newItemName": "wstqdr:glistering_melon_icecreamcone","count": 1}],1:[{"newItemName": "wstqdr:glistering_melon_icecreamcone","count": 2}],2:[{"newItemName": "wstqdr:glistering_melon_icecreamcone","count": 3}],3:[{"newItemName": "wstqdr:glistering_melon_icecreamcone","count": 4}]},"sound":{"name":"dig.cloth","volume":(0.8,1.0),"pitch":(0.8,1.0)}},
    ("wstqdr:glow_berry_icecreamcone","wstqdr:glow_berry_icecreamcone_block"):{"Stackable":{"stageMin":0,"stageMax":3},"DropList":{0:[{"newItemName": "wstqdr:glow_berry_icecreamcone","count": 1}],1:[{"newItemName": "wstqdr:glow_berry_icecreamcone","count": 2}],2:[{"newItemName": "wstqdr:glow_berry_icecreamcone","count": 3}],3:[{"newItemName": "wstqdr:glow_berry_icecreamcone","count": 4}]},"sound":{"name":"dig.cloth","volume":(0.8,1.0),"pitch":(0.8,1.0)}},
    ("wstqdr:melon_icecreamcone","wstqdr:melon_icecreamcone_block"):{"Stackable":{"stageMin":0,"stageMax":3},"DropList":{0:[{"newItemName": "wstqdr:melon_icecreamcone","count": 1}],1:[{"newItemName": "wstqdr:melon_icecreamcone","count": 2}],2:[{"newItemName": "wstqdr:melon_icecreamcone","count": 3}],3:[{"newItemName": "wstqdr:melon_icecreamcone","count": 4}]},"sound":{"name":"dig.cloth","volume":(0.8,1.0),"pitch":(0.8,1.0)}},
    ("wstqdr:strawberry_icecreamcone","wstqdr:strawberry_icecreamcone_block"):{"Stackable":{"stageMin":0,"stageMax":3},"DropList":{0:[{"newItemName": "wstqdr:strawberry_icecreamcone","count": 1}],1:[{"newItemName": "wstqdr:strawberry_icecreamcone","count": 2}],2:[{"newItemName": "wstqdr:strawberry_icecreamcone","count": 3}],3:[{"newItemName": "wstqdr:strawberry_icecreamcone","count": 4}]},"sound":{"name":"dig.cloth","volume":(0.8,1.0),"pitch":(0.8,1.0)}},
    ("wstqdr:sweet_berry_icecreamcone","wstqdr:sweet_berry_icecreamcone_block"):{"Stackable":{"stageMin":0,"stageMax":3},"DropList":{0:[{"newItemName": "wstqdr:sweet_berry_icecreamcone","count": 1}],1:[{"newItemName": "wstqdr:sweet_berry_icecreamcone","count": 2}],2:[{"newItemName": "wstqdr:sweet_berry_icecreamcone","count": 3}],3:[{"newItemName": "wstqdr:sweet_berry_icecreamcone","count": 4}]},"sound":{"name":"dig.cloth","volume":(0.8,1.0),"pitch":(0.8,1.0)}},
    ("wstqdr:tomato_icecreamcone","wstqdr:tomato_icecreamcone_block"):{"Stackable":{"stageMin":0,"stageMax":3},"DropList":{0:[{"newItemName": "wstqdr:tomato_icecreamcone","count": 1}],1:[{"newItemName": "wstqdr:tomato_icecreamcone","count": 2}],2:[{"newItemName": "wstqdr:tomato_icecreamcone","count": 3}],3:[{"newItemName": "wstqdr:tomato_icecreamcone","count": 4}]},"sound":{"name":"dig.cloth","volume":(0.8,1.0),"pitch":(0.8,1.0)}},
    #冰淇淋杯
    ("wstqdr:icecreamcup","wstqdr:icecreamcup_block"):{"DropList":{0:[{"newItemName": "wstqdr:icecreamcup","count": 1}],1:[{"newItemName": "minecraft:glass_bottle","count": 1}],2:[{"newItemName": "minecraft:glass_bottle","count": 1}],3:[{"newItemName": "minecraft:glass_bottle","count": 1}]}},
    ("wstqdr:apple_icecreamcup","wstqdr:apple_icecreamcup_block"):{"DropList":{0:[{"newItemName": "wstqdr:apple_icecreamcup","count": 1}],1:[{"newItemName": "minecraft:glass_bottle","count": 1}],2:[{"newItemName": "minecraft:glass_bottle","count": 1}],3:[{"newItemName": "minecraft:glass_bottle","count": 1}]}},
    ("wstqdr:banana_icecreamcup","wstqdr:banana_icecreamcup_block"):{"DropList":{0:[{"newItemName": "wstqdr:banana_icecreamcup","count": 1}],1:[{"newItemName": "minecraft:glass_bottle","count": 1}],2:[{"newItemName": "minecraft:glass_bottle","count": 1}],3:[{"newItemName": "minecraft:glass_bottle","count": 1}]}},
    ("wstqdr:blue_berry_icecreamcup","wstqdr:blue_berry_icecreamcup_block"):{"DropList":{0:[{"newItemName": "wstqdr:blue_berry_icecreamcup","count": 1}],1:[{"newItemName": "minecraft:glass_bottle","count": 1}],2:[{"newItemName": "minecraft:glass_bottle","count": 1}],3:[{"newItemName": "minecraft:glass_bottle","count": 1}]}},
    ("wstqdr:chocolate_icecreamcup","wstqdr:chocolate_icecreamcup_block"):{"DropList":{0:[{"newItemName": "wstqdr:chocolate_icecreamcup","count": 1}],1:[{"newItemName": "minecraft:glass_bottle","count": 1}],2:[{"newItemName": "minecraft:glass_bottle","count": 1}],3:[{"newItemName": "minecraft:glass_bottle","count": 1}]}},
    ("wstqdr:chorus_fruit_icecreamcup","wstqdr:chorus_fruit_icecreamcup_block"):{"DropList":{0:[{"newItemName": "wstqdr:chorus_fruit_icecreamcup","count": 1}],1:[{"newItemName": "minecraft:glass_bottle","count": 1}],2:[{"newItemName": "minecraft:glass_bottle","count": 1}],3:[{"newItemName": "minecraft:glass_bottle","count": 1}]}},
    ("wstqdr:corn_icecreamcup","wstqdr:corn_icecreamcup_block"):{"DropList":{0:[{"newItemName": "wstqdr:corn_icecreamcup","count": 1}],1:[{"newItemName": "minecraft:glass_bottle","count": 1}],2:[{"newItemName": "minecraft:glass_bottle","count": 1}],3:[{"newItemName": "minecraft:glass_bottle","count": 1}]}},
    ("wstqdr:cream_icecreamcup","wstqdr:cream_icecreamcup_block"):{"DropList":{0:[{"newItemName": "wstqdr:cream_icecreamcup","count": 1}],1:[{"newItemName": "minecraft:glass_bottle","count": 1}],2:[{"newItemName": "minecraft:glass_bottle","count": 1}],3:[{"newItemName": "minecraft:glass_bottle","count": 1}]}},
    ("wstqdr:glistering_melon_icecreamcup","wstqdr:glistering_melon_icecreamcup_block"):{"DropList":{0:[{"newItemName": "wstqdr:glistering_melon_icecreamcup","count": 1}],1:[{"newItemName": "minecraft:glass_bottle","count": 1}],2:[{"newItemName": "minecraft:glass_bottle","count": 1}],3:[{"newItemName": "minecraft:glass_bottle","count": 1}]}},
    ("wstqdr:glow_berry_icecreamcup","wstqdr:glow_berry_icecreamcup_block"):{"DropList":{0:[{"newItemName": "wstqdr:glow_berry_icecreamcup","count": 1}],1:[{"newItemName": "minecraft:glass_bottle","count": 1}],2:[{"newItemName": "minecraft:glass_bottle","count": 1}],3:[{"newItemName": "minecraft:glass_bottle","count": 1}]}},
    ("wstqdr:melon_icecreamcup","wstqdr:melon_icecreamcup_block"):{"DropList":{0:[{"newItemName": "wstqdr:melon_icecreamcup","count": 1}],1:[{"newItemName": "minecraft:glass_bottle","count": 1}],2:[{"newItemName": "minecraft:glass_bottle","count": 1}],3:[{"newItemName": "minecraft:glass_bottle","count": 1}]}},
    ("wstqdr:strawberry_icecreamcup","wstqdr:strawberry_icecreamcup_block"):{"DropList":{0:[{"newItemName": "wstqdr:strawberry_icecreamcup","count": 1}],1:[{"newItemName": "minecraft:glass_bottle","count": 1}],2:[{"newItemName": "minecraft:glass_bottle","count": 1}],3:[{"newItemName": "minecraft:glass_bottle","count": 1}]}},
    ("wstqdr:sweet_berry_icecreamcup","wstqdr:sweet_berry_icecreamcup_block"):{"DropList":{0:[{"newItemName": "wstqdr:sweet_berry_icecreamcup","count": 1}],1:[{"newItemName": "minecraft:glass_bottle","count": 1}],2:[{"newItemName": "minecraft:glass_bottle","count": 1}],3:[{"newItemName": "minecraft:glass_bottle","count": 1}]}},
    ("wstqdr:tomato_icecreamcup","wstqdr:tomato_icecreamcup_block"):{"DropList":{0:[{"newItemName": "wstqdr:tomato_icecreamcup","count": 1}],1:[{"newItemName": "minecraft:glass_bottle","count": 1}],2:[{"newItemName": "minecraft:glass_bottle","count": 1}],3:[{"newItemName": "minecraft:glass_bottle","count": 1}]}},
    #雪泥大王
    ("wstqdr:snow_smoothie","wstqdr:snow_smoothie_block"):{"CanHold":True,"DropList":[{"newItemName": "wstqdr:snow_smoothie","count": 1}]},
    ("wstqdr:apple_smoothie","wstqdr:apple_smoothie_block"):{"CanHold":True,"DropList":[{"newItemName": "wstqdr:apple_smoothie","count": 1}]},
    ("wstqdr:banana_smoothie","wstqdr:banana_smoothie_block"):{"CanHold":True,"DropList":[{"newItemName": "wstqdr:banana_smoothie","count": 1}]},
    ("wstqdr:blue_berry_smoothie","wstqdr:blue_berry_smoothie_block"):{"CanHold":True,"DropList":[{"newItemName": "wstqdr:blue_berry_smoothie","count": 1}]},
    ("wstqdr:chocolate_carrot_smoothie","wstqdr:chocolate_carrot_smoothie_block"):{"CanHold":True,"DropList":[{"newItemName": "wstqdr:chocolate_carrot_smoothie","count": 1}]},
    ("wstqdr:chocolate_smoothie","wstqdr:chocolate_smoothie_block"):{"CanHold":True,"DropList":[{"newItemName": "wstqdr:chocolate_smoothie","count": 1}]},
    ("wstqdr:chorus_fruit_smoothie","wstqdr:chorus_fruit_smoothie_block"):{"CanHold":True,"DropList":[{"newItemName": "wstqdr:chorus_fruit_icecrsmoothie","count": 1}]},
    ("wstqdr:corn_smoothie","wstqdr:corn_smoothie_block"):{"CanHold":True,"DropList":[{"newItemName": "wstqdr:corn_smoothie","count": 1}]},
    ("wstqdr:cream_smoothie","wstqdr:cream_smoothie_block"):{"CanHold":True,"DropList":[{"newItemName": "wstqdr:cream_smoothie","count": 1}]},
    ("wstqdr:glistering_melon_smoothie","wstqdr:glistering_melon_smoothie_block"):{"CanHold":True,"DropList":[{"newItemName": "wstqdr:glistering_melon_smoothie","count": 1}]},
    ("wstqdr:glow_berry_smoothie","wstqdr:glow_berry_smoothie_block"):{"CanHold":True,"DropList":[{"newItemName": "wstqdr:glow_berry_smoothie","count": 1}]},
    ("wstqdr:grape_smoothie","wstqdr:grape_smoothie_block"):{"CanHold":True,"DropList":[{"newItemName": "wstqdr:grape_smoothie","count": 1}]},
    ("wstqdr:honey_smoothie","wstqdr:honey_smoothie_block"):{"CanHold":True,"DropList":[{"newItemName": "wstqdr:honey_smoothie","count": 1}]},
    ("wstqdr:melon_smoothie","wstqdr:melon_smoothie_block"):{"CanHold":True,"DropList":[{"newItemName": "wstqdr:melon_smoothie","count": 1}]},
    ("wstqdr:strawberry_smoothie","wstqdr:strawberry_smoothie_block"):{"CanHold":True,"DropList":[{"newItemName": "wstqdr:strawberry_smoothie","count": 1}]},
    ("wstqdr:sweet_berry_smoothie","wstqdr:sweet_berry_smoothie_block"):{"CanHold":True,"DropList":[{"newItemName": "wstqdr:sweet_berry_smoothie","count": 1}]},
    ("wstqdr:tomato_smoothie","wstqdr:tomato_smoothie_block"):{"CanHold":True,"DropList":[{"newItemName": "wstqdr:tomato_smoothie","count": 1}]},
}
#饱和公式:饥饿度乘以2倍系数(差:0.1，低:0.3，普通:0.6，好:0.8，超自然:1.2,网易特有的超高:1)
PlatedFrozenFoods = {
    #冰淇淋杯
    "wstqdr:icecreamcup_block":{"stageMin":0,"stageMax":3,"hunger":2,"saturation":2.4,"stagehungers":{3:{"hunger":0,"saturation":0}},"DropList":{3:[{"newItemName": "minecraft:glass_bottle","count": 1}]},"Effect":[{"effectName":"speed","duration": 10,"amplifier": 0,"showParticles": True,"Maxduration": 30}],"sound":{"name":"random.eat","volume":(0.5,1.1),"pitch":(0.8,1.2),"stagesounds":{3:{"name":"random.pop","volume":(0.5,0.6),"pitch":(0.55,0.75)}}}},
    "wstqdr:apple_icecreamcup_block":{"stageMin":0,"stageMax":3,"hunger":2,"saturation":2.4,"stagehungers":{3:{"hunger":0,"saturation":0}},"DropList":{3:[{"newItemName": "minecraft:glass_bottle","count": 1}]},"Effect":[{"effectName":"speed","duration": 10,"amplifier": 0,"showParticles": True,"Maxduration": 30},{"effectName":"absorption","duration": 10,"amplifier": 0,"showParticles": True,"Maxduration": 30}],"sound":{"name":"random.eat","volume":(0.5,1.1),"pitch":(0.8,1.2),"stagesounds":{3:{"name":"random.pop","volume":(0.5,0.6),"pitch":(0.55,0.75)}}}},
    "wstqdr:banana_icecreamcup_block":{"stageMin":0,"stageMax":3,"hunger":2,"saturation":2.4,"stagehungers":{3:{"hunger":0,"saturation":0}},"DropList":{3:[{"newItemName": "minecraft:glass_bottle","count": 1}]},"Effect":[{"effectName":"speed","duration": 10,"amplifier": 0,"showParticles": True,"Maxduration": 30}],"sound":{"name":"random.eat","volume":(0.5,1.1),"pitch":(0.8,1.2),"stagesounds":{3:{"name":"random.pop","volume":(0.5,0.6),"pitch":(0.55,0.75)}}}},
    "wstqdr:blue_berry_icecreamcup_block":{"stageMin":0,"stageMax":3,"hunger":2,"saturation":2.4,"stagehungers":{3:{"hunger":0,"saturation":0}},"DropList":{3:[{"newItemName": "minecraft:glass_bottle","count": 1}]},"Effect":[{"effectName":"speed","duration": 10,"amplifier": 0,"showParticles": True,"Maxduration": 30}],"sound":{"name":"random.eat","volume":(0.5,1.1),"pitch":(0.8,1.2),"stagesounds":{3:{"name":"random.pop","volume":(0.5,0.6),"pitch":(0.55,0.75)}}}},
    "wstqdr:chocolate_icecreamcup_block":{"stageMin":0,"stageMax":3,"hunger":2,"saturation":2.4,"stagehungers":{3:{"hunger":0,"saturation":0}},"DropList":{3:[{"newItemName": "minecraft:glass_bottle","count": 1}]},"Effect":[{"effectName":"speed","duration": 10,"amplifier": 0,"showParticles": True,"Maxduration": 30},{"effectName":"haste","duration": 20,"amplifier": 1,"showParticles": True,"Maxduration": 30},{"effectName":"resistance","duration": 10,"amplifier": 0,"showParticles": True,"Maxduration": 30}],"sound":{"name":"random.eat","volume":(0.5,1.1),"pitch":(0.8,1.2),"stagesounds":{3:{"name":"random.pop","volume":(0.5,0.6),"pitch":(0.55,0.75)}}}},
    "wstqdr:chorus_fruit_icecreamcup_block":{"stageMin":0,"stageMax":3,"hunger":2,"saturation":2.4,"stagehungers":{3:{"hunger":0,"saturation":0}},"DropList":{3:[{"newItemName": "minecraft:glass_bottle","count": 1}]},"Effect":[{"effectName":"speed","duration": 10,"amplifier": 0,"showParticles": True,"Maxduration": 30}],"sound":{"name":"random.eat","volume":(0.5,1.1),"pitch":(0.8,1.2),"stagesounds":{3:{"name":"random.pop","volume":(0.5,0.6),"pitch":(0.55,0.75)}}}},
    "wstqdr:corn_icecreamcup_block":{"stageMin":0,"stageMax":3,"hunger":2,"saturation":2.4,"stagehungers":{3:{"hunger":0,"saturation":0}},"DropList":{3:[{"newItemName": "minecraft:glass_bottle","count": 1}]},"Effect":[{"effectName":"speed","duration": 10,"amplifier": 0,"showParticles": True,"Maxduration": 30}],"sound":{"name":"random.eat","volume":(0.5,1.1),"pitch":(0.8,1.2),"stagesounds":{3:{"name":"random.pop","volume":(0.5,0.6),"pitch":(0.55,0.75)}}}},
    "wstqdr:cream_icecreamcup_block":{"stageMin":0,"stageMax":3,"hunger":2,"saturation":2.4,"stagehungers":{3:{"hunger":0,"saturation":0}},"DropList":{3:[{"newItemName": "minecraft:glass_bottle","count": 1}]},"Effect":[{"effectName":"speed","duration": 10,"amplifier": 0,"showParticles": True,"Maxduration": 30}],"sound":{"name":"random.eat","volume":(0.5,1.1),"pitch":(0.8,1.2),"stagesounds":{3:{"name":"random.pop","volume":(0.5,0.6),"pitch":(0.55,0.75)}}}},
    "wstqdr:glistering_melon_icecreamcup_block":{"stageMin":0,"stageMax":3,"hunger":2,"saturation":2.4,"stagehungers":{3:{"hunger":0,"saturation":0}},"DropList":{3:[{"newItemName": "minecraft:glass_bottle","count": 1}]},"Effect":[{"effectName":"speed","duration": 10,"amplifier": 0,"showParticles": True,"Maxduration": 30},{"effectName":"regeneration","duration": 20,"amplifier": 1,"showParticles": True,"Maxduration": 60}],"sound":{"name":"random.eat","volume":(0.5,1.1),"pitch":(0.8,1.2),"stagesounds":{3:{"name":"random.pop","volume":(0.5,0.6),"pitch":(0.55,0.75)}}}},
    "wstqdr:glow_berry_icecreamcup_block":{"stageMin":0,"stageMax":3,"hunger":2,"saturation":2.4,"stagehungers":{3:{"hunger":0,"saturation":0}},"DropList":{3:[{"newItemName": "minecraft:glass_bottle","count": 1}]},"Effect":[{"effectName":"speed","duration": 10,"amplifier": 0,"showParticles": True,"Maxduration": 30}],"sound":{"name":"random.eat","volume":(0.5,1.1),"pitch":(0.8,1.2),"stagesounds":{3:{"name":"random.pop","volume":(0.5,0.6),"pitch":(0.55,0.75)}}}},
    "wstqdr:melon_icecreamcup_block":{"stageMin":0,"stageMax":3,"hunger":2,"saturation":2.4,"stagehungers":{3:{"hunger":0,"saturation":0}},"DropList":{3:[{"newItemName": "minecraft:glass_bottle","count": 1}]},"Effect":[{"effectName":"speed","duration": 10,"amplifier": 0,"showParticles": True,"Maxduration": 30},{"effectName":"regeneration","duration": 10,"amplifier": 0,"showParticles": True,"Maxduration": 30}],"sound":{"name":"random.eat","volume":(0.5,1.1),"pitch":(0.8,1.2),"stagesounds":{3:{"name":"random.pop","volume":(0.5,0.6),"pitch":(0.55,0.75)}}}},
    "wstqdr:strawberry_icecreamcup_block":{"stageMin":0,"stageMax":3,"hunger":2,"saturation":2.4,"stagehungers":{3:{"hunger":0,"saturation":0}},"DropList":{3:[{"newItemName": "minecraft:glass_bottle","count": 1}]},"Effect":[{"effectName":"speed","duration": 10,"amplifier": 0,"showParticles": True,"Maxduration": 30}],"sound":{"name":"random.eat","volume":(0.5,1.1),"pitch":(0.8,1.2),"stagesounds":{3:{"name":"random.pop","volume":(0.5,0.6),"pitch":(0.55,0.75)}}}},
    "wstqdr:sweet_berry_icecreamcup_block":{"stageMin":0,"stageMax":3,"hunger":2,"saturation":2.4,"stagehungers":{3:{"hunger":0,"saturation":0}},"DropList":{3:[{"newItemName": "minecraft:glass_bottle","count": 1}]},"Effect":[{"effectName":"speed","duration": 10,"amplifier": 0,"showParticles": True,"Maxduration": 30}],"sound":{"name":"random.eat","volume":(0.5,1.1),"pitch":(0.8,1.2),"stagesounds":{3:{"name":"random.pop","volume":(0.5,0.6),"pitch":(0.55,0.75)}}}},
    "wstqdr:tomato_icecreamcup_block":{"stageMin":0,"stageMax":3,"hunger":2,"saturation":2.4,"stagehungers":{3:{"hunger":0,"saturation":0}},"DropList":{3:[{"newItemName": "minecraft:glass_bottle","count": 1}]},"Effect":[{"effectName":"speed","duration": 10,"amplifier": 0,"showParticles": True,"Maxduration": 30},{"effectName":"regeneration","duration": 10,"amplifier": 0,"showParticles": True,"Maxduration": 30}],"sound":{"name":"random.eat","volume":(0.5,1.1),"pitch":(0.8,1.2),"stagesounds":{3:{"name":"random.pop","volume":(0.5,0.6),"pitch":(0.55,0.75)}}}},

}

SmoothieRecipeDict = {
    #雪泥大王配方~~~
    "wstqdr:apple_smoothie_block":{"UseItems":{"minecraft:apple"}},
    "wstqdr:banana_smoothie_block":{"UseItems":{"wstqdr:banana"}},
    "wstqdr:blue_berry_smoothie_block":{"UseItems":{"wstqdr:blue_berry"}},
    "wstqdr:chocolate_carrot_smoothie_block":{"UseItems":{"minecraft:carrot"},"CraftBlock":"wstqdr:chocolate_smoothie_block"},
    "wstqdr:chocolate_smoothie_block":{"UseItems":{"wstqdr:chocolate"}},
    "wstqdr:chorus_fruit_smoothie_block":{"UseItems":{"minecraft:chorus_fruit"}},
    "wstqdr:corn_smoothie_block":{"UseItems":{"wstqdr:corn"}},
    "wstqdr:cream_smoothie_block":{"UseItems":{"wstqdr:cream_bottle"},"container":{"newItemName":"minecraft:glass_bottle","count":1}},
    "wstqdr:glistering_melon_smoothie_block":{"UseItems":"minecraft:glistering_melon_slice"},
    "wstqdr:glow_berry_smoothie_block":{"UseItems":"minecraft:glow_berries"},
    "wstqdr:grape_smoothie_block":{"UseItems":"wstqdr:grape"},
    "wstqdr:honey_smoothie_block":{"UseItems":{"minecraft:honey_bottle"},"container":{"newItemName":"minecraft:glass_bottle","count":1}},
    "wstqdr:melon_smoothie_block":{"UseItems":"minecraft:melon_slice"},
    "wstqdr:strawberry_smoothie_block":{"UseItems":"wstqdr:strawberry"},
    "wstqdr:sweet_berry_smoothie_block":{"UseItems":"minecraft:sweet_berries"},
    "wstqdr:tomato_smoothie_block":{"UseItems":"wstqdr:tomato"}
}

PopsicleMoldRecipeDict = {
    #冰棍大王配方~~~
    "wstqdr:classic_popsicle":{"UseItems":{"minecraft:sugar"}},
    "wstqdr:apple_popsicle":{"UseItems":{"minecraft:apple"}},
    "wstqdr:banana_popsicle":{"UseItems":{"wstqdr:banana"}},
    "wstqdr:blue_berry_popsicle":{"UseItems":{"wstqdr:blue_berry"}},
    "wstqdr:chocolate_popsicle":{"UseItems":{"wstqdr:chocolate"}},
    "wstqdr:chorus_fruit_popsicle":{"UseItems":{"minecraft:chorus_fruit"}},
    "wstqdr:corn_popsicle":{"UseItems":{"wstqdr:corn"}},
    "wstqdr:cream_popsicle":{"UseItems":{"wstqdr:cream_bottle"},"container":{"newItemName":"minecraft:glass_bottle","count":1}},
    "wstqdr:glistering_melon_popsicle":{"UseItems":"minecraft:glistering_melon_slice"},
    "wstqdr:glow_berry_popsicle":{"UseItems":"minecraft:glow_berries"},
    "wstqdr:honey_popsicle":{"UseItems":{"minecraft:honey_bottle"},"container":{"newItemName":"minecraft:glass_bottle","count":1}},
    "wstqdr:melon_popsicle":{"UseItems":"minecraft:melon_slice"},
    "wstqdr:strawberry_popsicle":{"UseItems":"wstqdr:strawberry"},
    "wstqdr:sweet_berry_popsicle":{"UseItems":"minecraft:sweet_berries"},
    "wstqdr:tomato_popsicle":{"UseItems":"wstqdr:tomato"}
}

CanProvideColdItemDict = {
    "minecraft:ice":{"cold_level":1},
    "minecraft:packed_ice":{"cold_level":2},
    "minecraft:blue_ice":{"cold_level":3}
}

IceCreamChurnAbleItems = {
    "minecraft:egg":{},
    "minecraft:sugar":{},
    "minecraft:sweet_berries":{"RGB": {"r":200,"g":5,"b":5}},
    "minecraft:glow_berries":{"RGB": {"r":200,"g":200,"b":15}},
    "minecraft:glistering_melon_slice":{"RGB": {"r":200,"g":180,"b":45}},
    "minecraft:apple":{"RGB": {"r":135,"g":95,"b":45}},
    "minecraft:melon_slice":{"RGB": {"r":180,"g":25,"b":15}},
    "minecraft:chorus_fruit":{"RGB": {"r":135,"g":85,"b":185}},
    "minecraft:cookie":{"RGB": {"r":145,"g":70,"b":20}},
    "wstqdr:chocolate":{"RGB": {"r":115,"g":65,"b":15}},
    "wstqdr:tomato":{"RGB": {"r":185,"g":35,"b":5}},
    "wstqdr:blue_berry":{"RGB": {"r":165,"g":0,"b":145}},
    "wstqdr:corn":{"RGB": {"r":205,"g":155,"b":0}},
    "wstqdr:banana":{"RGB": {"r":145,"g":125,"b":55}},
    "wstqdr:strawberry":{"RGB": {"r":200,"g":80,"b":80}},
}

IceCreamChurnAbleLiquid =  {
    "minecraft:milk_bucket":{"RGB": {"r":225,"g":225,"b":225},"NoBlendRGB":True,"container":{"newItemName":"minecraft:bucket","count":1}},
    "wstqdr:cream_bucket":{"RGB": {"r":225,"g":225,"b":200},"NoBlendRGB":True,"container":{"newItemName":"minecraft:bucket","count":1}},
}
IceCreamChurnRecipeList = [
    {
        "input": [
            {"newItemName": "minecraft:sugar","count": (1,2)},
            {"newItemName": "minecraft:egg","count": (1,2)},
            {"newItemName": "minecraft:milk_bucket","count": 1}
        ],
        "output": {
            "minecraft:glass_bottle":{"newItemName": "wstqdr:icecreamcup", "count": 1, "newAuxValue": 0},
            "wstqdr:waffle_cone":{"newItemName": "wstqdr:icecreamcone", "count": 1, "newAuxValue": 0}
        },
        "text":"冰淇淋",
        "container_text":"华夫脆筒或玻璃瓶"
    },
    {
        "input": [
            {"newItemName": "minecraft:sugar","count": (1,2)},
            {"newItemName": "minecraft:apple","count": (1,3)},
            {"newItemName": "minecraft:egg","count": (1,2)},
            {"newItemName": "minecraft:milk_bucket","count": 1}
        ],
        "output": {
            "minecraft:glass_bottle":{"newItemName": "wstqdr:apple_icecreamcup", "count": 1, "newAuxValue": 0},
            "wstqdr:waffle_cone":{"newItemName": "wstqdr:apple_icecreamcone", "count": 1, "newAuxValue": 0}
        },
        "text":"苹果冰淇淋",
        "container_text":"华夫脆筒或玻璃瓶"
    },

    {
        "input": [
            {"newItemName": "minecraft:sugar","count": (1,2)},
            {"newItemName": "wstqdr:banana","count": (1,3)},
            {"newItemName": "minecraft:egg","count": (1,2)},
            {"newItemName": "minecraft:milk_bucket","count": 1}
        ],
        "output": {
            "minecraft:glass_bottle":{"newItemName": "wstqdr:banana_icecreamcup", "count": 1, "newAuxValue": 0},
            "wstqdr:waffle_cone":{"newItemName": "wstqdr:banana_icecreamcone", "count": 1, "newAuxValue": 0}
        },
        "text":"香蕉冰淇淋",
        "container_text":"华夫脆筒或玻璃瓶"
    },
    {
        "input": [
            {"newItemName": "minecraft:sugar","count": (1,2)},
            {"newItemName": "wstqdr:blue_berry","count": (1,3)},
            {"newItemName": "minecraft:egg","count": (1,2)},
            {"newItemName": "minecraft:milk_bucket","count": 1}
        ],
        "output": {
            "minecraft:glass_bottle":{"newItemName": "wstqdr:blue_berry_icecreamcup", "count": 1, "newAuxValue": 0},
            "wstqdr:waffle_cone":{"newItemName": "wstqdr:blue_berry_icecreamcone", "count": 1, "newAuxValue": 0}
        },
        "text":"蓝莓冰淇淋",
        "container_text":"华夫脆筒或玻璃瓶"
    },
    {
        "input": [
            {"newItemName": "minecraft:sugar","count": (1,2)},
            {"newItemName": "wstqdr:chocolate","count": (1,3)},
            {"newItemName": "minecraft:egg","count": (1,2)},
            {"newItemName": "minecraft:milk_bucket","count": 1}
        ],
        "output": {
            "minecraft:glass_bottle":{"newItemName": "wstqdr:chocolate_icecreamcup", "count": 1, "newAuxValue": 0},
            "wstqdr:waffle_cone":{"newItemName": "wstqdr:chocolate_icecreamcone", "count": 1, "newAuxValue": 0}
        },
        "text":"巧克力冰淇淋",
        "container_text":"华夫脆筒或玻璃瓶"
    },
    {
        "input": [
            {"newItemName": "minecraft:sugar","count": (1,2)},
            {"newItemName": "minecraft:chorus_fruit","count": (1,3)},
            {"newItemName": "minecraft:egg","count": (1,2)},
            {"newItemName": "minecraft:milk_bucket","count": 1}
        ],
        "output": {
            "minecraft:glass_bottle":{"newItemName": "wstqdr:chorus_fruit_icecreamcup", "count": 1, "newAuxValue": 0},
            "wstqdr:waffle_cone":{"newItemName": "wstqdr:chorus_fruit_icecreamcone", "count": 1, "newAuxValue": 0}
        },
        "text":"紫颂果冰淇淋",
        "container_text":"华夫脆筒或玻璃瓶"
    },
    {
        "input": [
            {"newItemName": "minecraft:sugar","count": (1,2)},
            {"newItemName": "wstqdr:corn","count": (1,3)},
            {"newItemName": "minecraft:egg","count": (1,2)},
            {"newItemName": "minecraft:milk_bucket","count": 1}
        ],
        "output": {
            "minecraft:glass_bottle":{"newItemName": "wstqdr:corn_icecreamcup", "count": 1, "newAuxValue": 0},
            "wstqdr:waffle_cone":{"newItemName": "wstqdr:corn_icecreamcone", "count": 1, "newAuxValue": 0}
        },
        "text":"玉米冰淇淋",
        "container_text":"华夫脆筒或玻璃瓶"
    },
    {
        "input": [
            {"newItemName": "minecraft:sugar","count": (1,2)},
            {"newItemName": "minecraft:egg","count": (1,2)},
            {"newItemName": "wstqdr:cream_bucket","count": 1}
        ],
        "output": {
            "minecraft:glass_bottle":{"newItemName": "wstqdr:cream_icecreamcup", "count": 1, "newAuxValue": 0},
            "wstqdr:waffle_cone":{"newItemName": "wstqdr:cream_icecreamcone", "count": 1, "newAuxValue": 0}
        },
        "text":"奶油冰淇淋",
        "container_text":"华夫脆筒或玻璃瓶"
    },
    {
        "input": [
            {"newItemName": "minecraft:sugar","count": (1,2)},
            {"newItemName": "minecraft:melon_slice","count": (1,3)},
            {"newItemName": "minecraft:egg","count": (1,2)},
            {"newItemName": "minecraft:milk_bucket","count": 1}
        ],
        "output": {
            "minecraft:glass_bottle":{"newItemName": "wstqdr:melon_icecreamcup", "count": 1, "newAuxValue": 0},
            "wstqdr:waffle_cone":{"newItemName": "wstqdr:melon_icecreamcone", "count": 1, "newAuxValue": 0}
        },
        "text":"西瓜冰淇淋",
        "container_text":"华夫脆筒或玻璃瓶"
    },
    {
        "input": [
            {"newItemName": "minecraft:sugar","count": (1,2)},
            {"newItemName": "minecraft:glistering_melon_slice","count": (1,3)},
            {"newItemName": "minecraft:egg","count": (1,2)},
            {"newItemName": "minecraft:milk_bucket","count": 1}
        ],
        "output": {
            "minecraft:glass_bottle":{"newItemName": "wstqdr:glistering_melon_icecreamcup", "count": 1, "newAuxValue": 0},
            "wstqdr:waffle_cone":{"newItemName": "wstqdr:glistering_melon_icecreamcone", "count": 1, "newAuxValue": 0}
        },
        "text":"闪烁的西瓜冰淇淋",
        "container_text":"华夫脆筒或玻璃瓶"
    },
    {
        "input": [
            {"newItemName": "minecraft:sugar","count": (1,2)},
            {"newItemName": "minecraft:glow_berries","count": (1,3)},
            {"newItemName": "minecraft:egg","count": (1,2)},
            {"newItemName": "minecraft:milk_bucket","count": 1}
        ],
        "output": {
            "minecraft:glass_bottle":{"newItemName": "wstqdr:glow_berry_icecreamcup", "count": 1, "newAuxValue": 0},
            "wstqdr:waffle_cone":{"newItemName": "wstqdr:glow_berry_icecreamcone", "count": 1, "newAuxValue": 0}
        },
        "text":"发光浆果冰淇淋",
        "container_text":"华夫脆筒或玻璃瓶"
    },
    {
        "input": [
            {"newItemName": "minecraft:sugar","count": (1,2)},
            {"newItemName": "wstqdr:strawberry","count": (1,3)},
            {"newItemName": "minecraft:egg","count": (1,2)},
            {"newItemName": "minecraft:milk_bucket","count": 1}
        ],
        "output": {
            "minecraft:glass_bottle":{"newItemName": "wstqdr:strawberry_icecreamcup", "count": 1, "newAuxValue": 0},
            "wstqdr:waffle_cone":{"newItemName": "wstqdr:strawberry_icecreamcone", "count": 1, "newAuxValue": 0}
        },
        "text":"草莓冰淇淋",
        "container_text":"华夫脆筒或玻璃瓶"
    },
    {
        "input": [
            {"newItemName": "minecraft:sugar","count": (1,2)},
            {"newItemName": "minecraft:sweet_berries","count": (1,3)},
            {"newItemName": "minecraft:egg","count": (1,2)},
            {"newItemName": "minecraft:milk_bucket","count": 1}
        ],
        "output": {
            "minecraft:glass_bottle":{"newItemName": "wstqdr:sweet_berry_icecreamcup", "count": 1, "newAuxValue": 0},
            "wstqdr:waffle_cone":{"newItemName": "wstqdr:sweet_berry_icecreamcone", "count": 1, "newAuxValue": 0}
        },
        "text":"甜浆果冰淇淋",
        "container_text":"华夫脆筒或玻璃瓶"
    },
    {
        "input": [
            {"newItemName": "minecraft:sugar","count": (1,2)},
            {"newItemName": "wstqdr:tomato","count": (1,3)},
            {"newItemName": "minecraft:egg","count": (1,2)},
            {"newItemName": "minecraft:milk_bucket","count": 1}
        ],
        "output": {
            "minecraft:glass_bottle":{"newItemName": "wstqdr:tomato_icecreamcup", "count": 1, "newAuxValue": 0},
            "wstqdr:waffle_cone":{"newItemName": "wstqdr:tomato_icecreamcone", "count": 1, "newAuxValue": 0}
        },
        "text":"番茄冰淇淋",
        "container_text":"华夫脆筒或玻璃瓶"
    }
]
