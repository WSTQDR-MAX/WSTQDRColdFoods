# -*- coding: utf-8 -*-
from WSTQDRFrozenFoodScript.QuModLibs.Client import *
from WSTQDRFrozenFoodScript.QuModLibs.Client import _loaderSystem
CompFactory = clientApi.GetEngineCompFactory()

@AllowCall
def OnPlaySound(args={}):
    soundName = args["soundName"]
    pos = args["pos"]
    volume = args["volume"]
    pitch = args["pitch"]
    CompFactory.CreateCustomAudio(levelId).PlayCustomMusic(soundName, pos, volume, pitch, False, None)

@AllowCall
def PlayParticle(args={}):
    pos = args["pos"]
    ParticleName = args["ParticleName"]
    CompFactory.CreateParticleSystem(None).Create(ParticleName, pos)

@AllowCall
def SetMolang(args={}):
    entityId = args["entityId"]
    Molang = args["Molang"]
    Value = args["Value"]
    CompFactory.CreateQueryVariable(entityId).Set(Molang, Value)
    
@AllowCall
def SetEntityBlockMolang(args={}):
    pos = args["blockPos"]
    molang = args["molang"]
    name = args["name"]
    CompFactory.CreateBlockInfo(levelId).SetEnableBlockEntityAnimations(pos, True)
    CompFactory.CreateBlockInfo(levelId).SetBlockEntityMolangValue(pos, name, molang)

@AllowCall
def PlaySwing():
    CompFactory.CreatePlayer(playerId).Swing()   

@Listen(Events.LoadClientAddonScriptsAfter)
def LoadAddon(args={}):
    CompFactory.CreateQueryVariable(levelId).Register('query.mod.wstqdr_icecreamchurn_fill_mode', 0.0)
    