# -*- coding: utf-8 -*-
from QuModLibs.QuMod import *
WSTQDR_Mod = EasyMod(modDirName="WSTQDRFrozenFoodScript")
WSTQDR_SERVER = [
    "Script_Server.SaturatedFreeze",
    "Script_Server.IceCreamChurn",
    "Script_Server.PlatedFrozenFoods",
    "Script_Server.Smoothie",
    "Script_Server.PopsicleMold",
    "Script_Server.MiningSilkTouch",
    "Script_Server.WSTQDRFrozenFoodEntity",
    "Script_Server.WSTQDR_Common"
]
WSTQDR_CLIERNT = [
    "Script_Client.WSTQDRClientSystem",
    "Script_Client.WSTQDRFrozenFoods"
]
for Qu in WSTQDR_SERVER:
    WSTQDR_Mod.Server(Qu)
for Qu in WSTQDR_CLIERNT:
    WSTQDR_Mod.Client(Qu)    