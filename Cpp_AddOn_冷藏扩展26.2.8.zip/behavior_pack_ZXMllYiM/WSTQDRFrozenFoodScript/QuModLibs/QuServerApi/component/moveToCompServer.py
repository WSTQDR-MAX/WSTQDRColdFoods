# -*- coding: utf-8 -*-


class MoveToComponentServer(object):
    def SetMoveSetting(self, pos, speed, maxIteration, callback=None):
        # type: (tuple[float,float,float], float, int, function) -> None
        """
        寻路组件
        """
        pass

