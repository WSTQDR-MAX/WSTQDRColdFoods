# -*- coding: utf-8 -*-


class CollisionBoxComponentServer(object):
    def SetSize(self, size):
        # type: (tuple[float,float]) -> bool
        """
        设置实体的包围盒
        """
        pass

    def GetSize(self):
        # type: () -> tuple[float,float]
        """
        获取实体的包围盒
        """
        pass

