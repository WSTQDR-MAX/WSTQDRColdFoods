# -*- coding: utf-8 -*-
class ScreenNode(object):
    pass