# -*- coding: utf-8 -*-

from component.baseComponent import BaseComponent

class FrameAniEntityBindComp(BaseComponent):
    def Bind(self, bindEntityId, offset, rot):
        # type: (str, tuple[float,float,float], tuple[float,float,float]) -> bool
        """
        绑定entity
        """
        pass


