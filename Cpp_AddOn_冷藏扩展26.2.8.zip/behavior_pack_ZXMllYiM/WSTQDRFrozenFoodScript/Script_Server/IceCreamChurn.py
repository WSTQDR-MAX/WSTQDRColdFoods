# -*- coding: utf-8 -*-
from WSTQDRFrozenFoodScript.QuModLibs.Server import _loaderSystem
from WSTQDRFrozenFoodScript.Script_Functions.Functions import *
    
@Listen(Events.ServerBlockEntityTickEvent)
def OnServerIceCreamChurnEntityTickEvent(args={}):
    if args["blockName"] != "wstqdr:icecream_churn":
        return
    dimensionId = args["dimension"]
    blockPos = (args["posX"], args["posY"], args["posZ"])
    statecomp = CompFactory.CreateBlockState(None)
    blockstate = statecomp.GetBlockStates(blockPos)
    blockEntityData = CompFactory.CreateBlockEntityData(levelId).GetBlockEntityData(dimensionId, blockPos)
    if not blockEntityData["putintoLiquid"] and not blockEntityData["putintoList"]:
        return
    else:
        putintoLiquid = copy.deepcopy(blockEntityData["putintoLiquid"])
        putintoList = copy.deepcopy(blockEntityData["putintoList"])
    
    if not blockEntityData["churnTimer"]:
        blockEntityData["churnTimer"] = 0 
    if blockEntityData["churnCount"]: 
        if blockEntityData["churnTimer"] > 1:
            if blockstate["wstqdr:icecream_churn_stage"] == "ice": 
                blockEntityData["churnTimer"] -= 1
                print(blockEntityData["churnTimer"]) 
 
    if blockEntityData["churnTimer"] == 1 and blockEntityData["churnCount"] > 12:
        blockEntityData["churnTimer"] = None
        blockEntityData["churnCount"] = None
        print("进入配方检索")
        matched = False
        if blockstate["wstqdr:icecream_churn_stage"] == "ice": 
            for RecipeDict in IceCreamChurnRecipeList:#大循环里的是循环配方列表里面的各个配方字典
                #for里套3个for循环提取物品标识符，分别放入集合，以便后续判断
                for RecipeinputDict in RecipeDict["input"]:
                    if not blockEntityData["RecipeItemNameSet"]:
                        blockEntityData["RecipeItemNameSet"] = set([RecipeinputDict["newItemName"]])
                    else:
                        blockEntityData["RecipeItemNameSet"].add(RecipeinputDict["newItemName"])
                for putintoDict in putintoList if putintoList else []:
                    if not blockEntityData["putintoSet"]:
                        blockEntityData["putintoSet"] = set([putintoDict["newItemName"]])
                    else:
                        blockEntityData["putintoSet"].add(putintoDict["newItemName"])
                if putintoLiquid:
                    if not blockEntityData["putintoSet"]:
                        blockEntityData["putintoSet"] = set([putintoLiquid["newItemName"]])
                    else:
                        blockEntityData["putintoSet"].add(putintoLiquid["newItemName"])   
                if blockEntityData["RecipeItemNameSet"] == blockEntityData["putintoSet"]:
                    #RGB值的计算保存
                    if blockEntityData["putintorgb"]:
                        if blockEntityData["putintoRGB"]:
                            blockEntityData["putintoRGB"] += copy.deepcopy(blockEntityData["putintorgb"])
                        else:
                            blockEntityData["putintoRGB"] = copy.deepcopy(blockEntityData["putintorgb"])
                        blockEntityData["putintorgb"] = None
                        mix_rgb = MIX_RGB(blockEntityData["putintoRGB"])
                        PropertyList = [("wstqdr:red",mix_rgb[0]),("wstqdr:green",mix_rgb[1]),("wstqdr:blue",mix_rgb[2])]
                        #液体的展示实体是否存在，存在染色，不存在创造一个液体展示实体
                        if blockEntityData["liquidEntity"]:
                            DestroyEntity(blockEntityData["liquidEntity"])
                        blockEntityData["liquidEntity"] = Entity.CreateEngineEntityByTypeStr("wstqdr:icecreamchurn_fill",(args["posX"] + 0.5, args["posY"], args["posZ"] + 0.5),(0,0),dimensionId)
                        SetPropertyValue(blockEntityData["liquidEntity"],PropertyList)
                    #配方数量匹配
                    matched = True
                    blockEntityData["RecipeItemNameSet"] = None
                    blockEntityData["putintoSet"] = None
                    if not putintoList:
                        putintoList = [putintoLiquid]
                    else:
                        putintoList.append(putintoLiquid)
                    for RecipeinputDict in RecipeDict["input"]:
                        for putintoDict in putintoList:
                            if putintoDict["newItemName"] == RecipeinputDict["newItemName"]:
                                if type(RecipeinputDict["count"]) == tuple:
                                    if RecipeinputDict["count"][0] <= putintoDict["count"] <= RecipeinputDict["count"][1]:
                                        if not blockEntityData["countSet"]:
                                            blockEntityData["countSet"] = {1}
                                        else:
                                            blockEntityData["countSet"].add(1)
                                        print("数量匹配成功")
                                    else:
                                        if not blockEntityData["countSet"]:
                                            blockEntityData["countSet"] = {0}
                                        else:
                                            blockEntityData["countSet"].add(0)      
                                        print("数量匹配失败")
                                else:
                                    if RecipeinputDict["count"] == putintoDict["count"]:
                                        if not blockEntityData["countSet"]:
                                            blockEntityData["countSet"] = {1}
                                        else:
                                            blockEntityData["countSet"].add(1)
                                        print("数量匹配成功")
                                    else:
                                        if not blockEntityData["countSet"]:
                                            blockEntityData["countSet"] = {0}
                                        else:
                                            blockEntityData["countSet"].add(0)      
                                        print("数量匹配失败")
                    if matched and blockEntityData["countSet"] == {1}:
                        blockEntityData["RecipeDict"] = copy.deepcopy(RecipeDict)

                else:
                    #RGB值的计算保存
                    if blockEntityData["putintorgb"]:
                        if blockEntityData["putintoRGB"]:
                            blockEntityData["putintoRGB"] += copy.deepcopy(blockEntityData["putintorgb"])
                        else:
                            blockEntityData["putintoRGB"] = copy.deepcopy(blockEntityData["putintorgb"])
                        blockEntityData["putintorgb"] = None
                        mix_rgb = MIX_RGB(blockEntityData["putintoRGB"])
                        PropertyList = [("wstqdr:red",mix_rgb[0]),("wstqdr:green",mix_rgb[1]),("wstqdr:blue",mix_rgb[2])]
                        #液体的展示实体是否存在，存在染色，不存在创造一个液体展示实体
                        if blockEntityData["liquidEntity"]:
                            DestroyEntity(blockEntityData["liquidEntity"])
                        blockEntityData["liquidEntity"] = Entity.CreateEngineEntityByTypeStr("wstqdr:icecreamchurn_fill",(args["posX"] + 0.5, args["posY"], args["posZ"] + 0.5),(0,0),dimensionId)
                        SetPropertyValue(blockEntityData["liquidEntity"],PropertyList)
                    blockEntityData["RecipeItemNameSet"] = None
                    blockEntityData["putintoSet"] = None
                    continue        

            if matched and blockEntityData["countSet"] == {1}:  
                    blockEntityData["output"] = copy.deepcopy(blockEntityData["RecipeDict"]["output"])
                    blockEntityData["text"] = (copy.deepcopy(blockEntityData["RecipeDict"]["text"])).encode("utf-8")
                    blockEntityData["container_text"] = (copy.deepcopy(blockEntityData["RecipeDict"]["container_text"])).encode("utf-8")
                    blockEntityData["countSet"] = None         
                    blockEntityData["RecipeDict"] = None
                    blockEntityData["putintoLiquid"] = None
                    blockEntityData["putintoCount"] = None 
                    blockEntityData["putintoList"] = None
                    blockEntityData["churnFinished"] = True

                    #冰融化(冷度等级cold_level重置)
                    blockEntityData["cold_level"] = None
                    blockstate["wstqdr:icecream_churn_stage"] = "water"
                    statecomp.SetBlockStates(blockPos,blockstate,dimensionId)
                    return

            if not matched or blockEntityData["countSet"] == {1,0} or blockEntityData["countSet"] == {0}:
                    print("神秘冰淇淋")
                    blockEntityData["countSet"] = None
                    blockEntityData["putintoLiquid"] = None
                    blockEntityData["putintoCount"] = None 
                    blockEntityData["putintoList"] = None
                    blockEntityData["churnFinished"] = True
                    blockEntityData["output"] = {"wstqdr:waffle_cone":{"newItemName": "wstqdr:suspicious_icecreamcone", "count": 1},"minecraft:glass_bottle":{"newItemName": "wstqdr:suspicious_icecreamcup", "count": 1}}
                    blockEntityData["text"] = "神秘の冰淇淋"
                    blockEntityData["container_text"] = "华夫脆筒或玻璃瓶"
                    #冰融化(冷度等级cold_level重置)
                    blockEntityData["cold_level"] = None
                    blockstate["wstqdr:icecream_churn_stage"] = "water"
                    statecomp.SetBlockStates(blockPos,blockstate,dimensionId)
                    return
            

@Listen(Events.ServerBlockUseEvent)
def OnServerIceCreamChurnUseEvent(args={}):
    playerId = args["playerId"]
    blockName = args["blockName"]
    blockPos = (args["x"], args["y"], args["z"])
    Pos = CompFactory.CreatePos(playerId).GetFootPos()
    dimensionId = args["dimensionId"]
    Playercomp = CompFactory.CreatePlayer(playerId)
    statecomp = CompFactory.CreateBlockState(playerId)
    blockstate = statecomp.GetBlockStates(blockPos)
    if blockName == "wstqdr:icecream_churn":
        if SetPlayerUsedCD(playerId) is True:
            return
        blockEntityData = CompFactory.CreateBlockEntityData(levelId).GetBlockEntityData(dimensionId, blockPos)
        if not blockEntityData:
            return
            
        carriedDict = CompFactory.CreateItem(playerId).GetPlayerItem(2, 0, True)
        if carriedDict:#手中拿了物品
            #盛出冰淇淋原浆
            if blockEntityData["putintoLiquid"]:
                if carriedDict["newItemName"] == "minecraft:bucket":
                    DestroyEntity(blockEntityData["liquidEntity"])
                    ToAllPlayerPlaySound(dimensionId, blockPos, "bucket.fill_water")
                    SpawnLessItemsToPlayer(carriedDict,playerId)
                    SpawnItemToPlayer(blockEntityData["putintoLiquid"],playerId)
                    blockEntityData["putintoLiquid"] = None
                    blockEntityData["liquidEntity"] = None
                    blockEntityData["churnCount"] = None
                    putintoList = blockEntityData["putintoList"]
                    if putintoList:
                        blockEntityData["putintoCount"] = None 
                        blockEntityData["putintoList"] =None
                        for itemDict in putintoList:
                            if itemDict["count"] > 1:
                                Count = copy.deepcopy(itemDict["count"])
                                itemDict["count"] = 1
                                for i in range(Count):
                                    _loaderSystem.CreateEngineItemEntity(itemDict, dimensionId, (args["x"] + 0.5, args["y"] + random.uniform(0.5,1.0), args["z"] + 0.5))
                            else:
                                _loaderSystem.CreateEngineItemEntity(itemDict, dimensionId, (args["x"] + 0.5, args["y"] + random.uniform(0.5,1.0), args["z"] + 0.5))
                    return
            #盛出融化的冰
            if blockstate["wstqdr:icecream_churn_stage"] == "water":
                if carriedDict["newItemName"] == "minecraft:bucket":
                    blockstate["wstqdr:icecream_churn_stage"] = "none"
                    statecomp.SetBlockStates(blockPos,blockstate,dimensionId)
                    ToAllPlayerPlaySound(dimensionId, blockPos, "bucket.fill_water")
                    itemDict = {"newItemName":"minecraft:water_bucket", "count":1}
                    SpawnLessItemsToPlayer(carriedDict,playerId)
                    SpawnItemToPlayer(itemDict,playerId)
                    return
            #放入冷源(冰块)
            itemDict = copy.deepcopy(carriedDict)
            if carriedDict["newItemName"] in CanProvideColdItemDict:
                cold_level = CanProvideColdItemDict[carriedDict["newItemName"]].get("cold_level")
                if blockstate["wstqdr:icecream_churn_stage"] == "none":
                    if cold_level:
                        blockEntityData["cold_level"] = cold_level
                    blockstate["wstqdr:icecream_churn_stage"] = "ice"
                    statecomp.SetBlockStates(blockPos,blockstate,dimensionId)
                    ToAllPlayerPlaySound(dimensionId, blockPos, "armor.equip_leather")
                    SpawnLessItemsToPlayer(itemDict,playerId)
                elif blockstate["wstqdr:icecream_churn_stage"] == "ice":
                    CompFactory.CreateGame(playerId).SetOneTipMessage(playerId, "你已经放入冰块了哦...")
                else:
                    CompFactory.CreateGame(playerId).SetOneTipMessage(playerId, "也许你应该先把水盛出...")
                return
            #判断是否匹配冰淇淋容器成功
            if blockEntityData["output"]:
                if carriedDict["newItemName"] not in blockEntityData["output"]:
                    CompFactory.CreateGame(playerId).SetOneTipMessage(playerId, "请用%s盛出..." % blockEntityData["container_text"])
                    return
                SpawnItemToPlayer(blockEntityData["output"][carriedDict["newItemName"]],playerId)
                SpawnLessItemsToPlayer(carriedDict,playerId)
                ToAllPlayerPlaySound(dimensionId, blockPos, "armor.equip_leather")
                DestroyEntity(blockEntityData["liquidEntity"])
                blockEntityData["output"] = None
                blockEntityData["text"] = None
                blockEntityData["container_text"] = None
                blockEntityData["churnFinished"] = None
                blockEntityData["liquidEntity"] = None
                blockEntityData["putintoRGB"] = None
                statecomp.SetBlockStates(blockPos, blockstate, dimensionId)
            if carriedDict["newItemName"] in IceCreamChurnAbleLiquid:
                rgb = IceCreamChurnAbleLiquid.get(carriedDict["newItemName"]).get("RGB")
                NoBlendRGB = IceCreamChurnAbleLiquid.get(carriedDict["newItemName"]).get("NoBlendRGB")
                container = IceCreamChurnAbleLiquid.get(carriedDict["newItemName"]).get("container")
                if not rgb:
                    return
                if not blockEntityData["putintoLiquid"]: #放入液体，仅能一种
                    putintoliquid= copy.deepcopy(carriedDict)
                    putintoliquid["count"] = 1
                    blockEntityData["putintoLiquid"] = putintoliquid
                else:
                    CompFactory.CreateGame(playerId).SetOneTipMessage(playerId, "已经有冰淇淋原浆了...")
                    return
                #RGB值的计算保存
                if not NoBlendRGB:   
                    if not blockEntityData["putintoRGB"]:
                        blockEntityData["putintoRGB"] = [rgb]
                PropertyList = [("wstqdr:red",rgb["r"]),("wstqdr:green",rgb["g"]),("wstqdr:blue",rgb["b"])]
                #液体的展示实体是否存在，存在染色，不存在创造一个液体展示实体
                if blockEntityData["liquidEntity"]:
                    DestroyEntity(blockEntityData["liquidEntity"])
                blockEntityData["liquidEntity"] = Entity.CreateEngineEntityByTypeStr("wstqdr:icecreamchurn_fill",(args["x"] + 0.5, args["y"], args["z"] + 0.5),(0,0),dimensionId)
                SetPropertyValue(blockEntityData["liquidEntity"],PropertyList)

                SpawnLessItemsToPlayer(carriedDict,playerId)
                ToAllPlayerPlaySound(dimensionId, blockPos, "bucket.empty_water")
                if container:
                    SpawnItemToPlayer(container,playerId)
                blockEntityData["churnTimer"] = random.randint(1000,2000)

            if carriedDict["newItemName"] in IceCreamChurnAbleItems:  
                if not blockEntityData["putintoLiquid"]:
                    CompFactory.CreateGame(playerId).SetOneTipMessage(playerId, "请放入冰淇淋原浆...")
                    return
                rgb = IceCreamChurnAbleItems.get(carriedDict["newItemName"]).get("RGB")                  
                if not blockEntityData["putintoCount"]: #初始化 #放入第一个物品
                    putintoDict = copy.deepcopy(carriedDict)
                    putintoDict["count"] = 1
                    blockEntityData["putintoCount"] = 1
                    putintoList = [putintoDict]
                    blockEntityData["putintoList"] = putintoList
                else:
                    putintoList = copy.deepcopy(blockEntityData["putintoList"])
                    if blockEntityData["putintoCount"] < 6:
                        Found = False
                        for putintoDict in putintoList:
                            if putintoDict["newItemName"] == carriedDict["newItemName"]:
                                blockEntityData["putintoCount"] += 1
                                putintoList[putintoList.index(putintoDict)]["count"] += 1
                                Found = True
                                break
                        if not Found:                                                     
                            putintoDict = copy.deepcopy(carriedDict)
                            putintoDict["count"] = 1  
                            blockEntityData["putintoCount"] += 1
                            putintoList.append(putintoDict)   
                        blockEntityData["putintoList"] = putintoList
                    else:
                        return 
                #rgb值的计算保存,普通物品跟液体物品分开保存rbg和RGB，避免液体混合时提前渲染，和渲染错误
                putintorgb = blockEntityData["putintorgb"]
                if rgb:   
                    if not putintorgb:
                        putintorgb = [rgb]
                    else:
                        putintorgb.append(rgb)
                    blockEntityData["putintorgb"] = putintorgb
                SpawnLessItemsToPlayer(carriedDict,playerId)
                ToAllPlayerPlaySound(dimensionId, blockPos, "armor.equip_leather")
                  
        else:#手中没拿物品
            putintoList = blockEntityData["putintoList"]
            if not Playercomp.isSneaking():
                if putintoList:
                    for itemDict in putintoList:
                        SpawnItemToPlayer(itemDict,playerId)
                    ToAllPlayerPlaySound(dimensionId, blockPos, "armor.equip_leather")
                    blockEntityData["putintoCount"] = None 
                    blockEntityData["putintoList"] = None
                    blockEntityData["churnCount"] = None

            elif Playercomp.isSneaking():
                if blockEntityData["churnFinished"] == True:
                    CompFactory.CreateGame(playerId).SetOneTipMessage(playerId, "你的%s已经搅拌好啦!" % blockEntityData["text"])
                if not blockEntityData["churnCount"]:
                    if blockstate["wstqdr:icecream_churn_stage"] == "ice":
                        blockEntityData["churnCount"] = 1
                else:
                    if blockstate["wstqdr:icecream_churn_stage"] == "ice":
                        blockEntityData["churnCount"] += 1
                if blockstate["wstqdr:churn_stick_stage"] < 3:
                    blockstate["wstqdr:churn_stick_stage"] += 1
                    statecomp.SetBlockStates(blockPos,blockstate,dimensionId)
                    if blockstate["wstqdr:icecream_churn_stage"] == "ice":
                        if blockEntityData["churnTimer"] > 100:
                            if blockEntityData["cold_level"]:
                                blockEntityData["churnTimer"] -= (random.randint(20,40) + blockEntityData["cold_level"] * 10)
                            else:
                                blockEntityData["churnTimer"] -= random.randint(20,40)
                else:
                    blockstate["wstqdr:churn_stick_stage"] = 0
                    statecomp.SetBlockStates(blockPos,blockstate,dimensionId)
                    if blockstate["wstqdr:icecream_churn_stage"] == "ice":
                        if blockEntityData["churnTimer"] > 100:
                            if blockEntityData["cold_level"]:
                                blockEntityData["churnTimer"] -= (random.randint(20,40) + blockEntityData["cold_level"] * 10)
                            else:
                                blockEntityData["churnTimer"] -= random.randint(20,40)
                ToAllPlayerPlaySound(dimensionId, blockPos,"bucket.empty_powder_snow",1,random.uniform(0.5,0.8))   

@Listen(Events.BlockRemoveServerEvent)
def OnIceCreamChurnRemoveServerEvent(args={}):
    # 方块在销毁时触发
    blockPos = (args["x"], args["y"], args["z"])
    blockName = args["fullName"]
    dimensionId = args["dimension"]
    if blockName == "wstqdr:icecream_churn":
        blockEntityData = CompFactory.CreateBlockEntityData(levelId).GetBlockEntityData(dimensionId, blockPos)
        if not blockEntityData:
            return
        putintoList = blockEntityData["putintoList"]
        if putintoList:
            for itemDict in putintoList:
                if itemDict["count"] > 1:
                    Count = copy.deepcopy(itemDict["count"])
                    itemDict["count"] = 1
                    for i in range(Count):
                        _loaderSystem.CreateEngineItemEntity(itemDict, dimensionId, (args["x"] + 0.5, args["y"] + random.uniform(0.0,0.5), args["z"] + 0.5))
                else:
                    _loaderSystem.CreateEngineItemEntity(itemDict, dimensionId, (args["x"] + 0.5, args["y"] + random.uniform(0.0,0.5), args["z"] + 0.5))
        liquidEntity = blockEntityData["liquidEntity"]
        if liquidEntity:
            DestroyEntity(liquidEntity)

@Listen(Events.ServerItemUseOnEvent)
def OnServerIceCreamChurnItemUse(args):
    # 玩家在对方块使用物品之前服务端抛出的事件
    blockName = args["blockName"]
    entityId = args["entityId"]
    Playercomp = CompFactory.CreatePlayer(entityId)
    if blockName == "wstqdr:icecream_churn":
        if Playercomp.isSneaking():
            return
        args["ret"] = True