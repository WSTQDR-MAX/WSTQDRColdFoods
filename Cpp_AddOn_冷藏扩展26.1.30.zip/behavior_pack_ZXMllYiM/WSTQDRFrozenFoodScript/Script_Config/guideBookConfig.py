# -*- coding: utf-8 -*-

guidebookconfig = {
    "冷藏扩展":{
        "工具": [
            {
                "title": "雪泥",
                "namespace": "wstqdr:snow_smoothie",
                "auxValue": 0,
                "content": "潜行放下，可食用也可用于制作各种风味雪泥。\n用法：用配方指定物品点击雪泥即可获得。"
            },
            {
                "title": "冰棍模具",
                "namespace": "wstqdr:popsicle_mold",
                "auxValue": 0,
                "content": "放入冰块可用于制作冰棍。\n用法：将冰块放在冰棍模具中，放入配方指定物品，然后使用任意斧头点击，最后用木棍点击即可获得。"
            },
            {
                "title": "冰淇淋搅拌桶",
                "namespace": "wstqdr:icecream_churn",
                "auxValue": 0,
                "content": "可用于搅拌冰淇淋，目前接受两种原浆：奶桶和奶油桶。\n用法：放入冰块（冰、浮冰、蓝冰），按配方放入原浆、鸡蛋、糖和特定食物，当搅拌至少不小于12次且冷冻计时结束后即可得到冰淇淋。"
            }
        ],
        "冰淇淋配方": [
            {
                "title": "冰淇淋筒",
                "namespace": "wstqdr:icecreamcone",
                "auxValue": 0,
                "content": "可用冰淇淋搅拌桶制作。\n材料:1*奶桶 + 1~2*鸡蛋 + 1~2*糖。\n容器:1*华夫脆筒。\n返还:1*铁桶。"
            },
            {
                "title": "苹果冰淇淋筒",
                "namespace": "wstqdr:apple_icecreamcone",
                "auxValue": 0,
                "content": "可用冰淇淋搅拌桶制作。\n材料:1*奶桶 + 1~2*鸡蛋 + 1~2*糖 + 1~3*苹果。\n容器:1*华夫脆筒。\n返还:1*铁桶。"
            },
            {
                "title": "香蕉冰淇淋筒",
                "namespace": "wstqdr:banana_icecreamcone",
                "auxValue": 0,
                "content": "可用冰淇淋搅拌桶制作。\n材料:1*奶桶 + 1~2*鸡蛋 + 1~2*糖 + 1~3*香蕉。\n容器:1*华夫脆筒。\n返还:1*铁桶。"
            },
            {
                "title": "蓝莓冰淇淋筒",
                "namespace": "wstqdr:blue_berry_icecreamcone",
                "auxValue": 0,
                "content": "可用冰淇淋搅拌桶制作。\n材料:1*奶桶 + 1~2*鸡蛋 + 1~2*糖 + 1~3*蓝莓。\n容器:1*华夫脆筒。\n返还:1*铁桶。"
            },
            {
                "title": "巧克力冰淇淋筒",
                "namespace": "wstqdr:chocolate_icecreamcone",
                "auxValue": 0,
                "content": "可用冰淇淋搅拌桶制作。\n材料:1*奶桶 + 1~2*鸡蛋 + 1~2*糖 + 1~3*巧克力。\n容器:1*华夫脆筒。\n返还:1*铁桶。"
            },
            {
                "title": "紫颂果冰淇淋筒",
                "namespace": "wstqdr:chorus_fruit_icecreamcone",
                "auxValue": 0,
                "content": "可用冰淇淋搅拌桶制作。\n材料:1*奶桶 + 1~2*鸡蛋 + 1~2*糖 + 1~3*紫颂果。\n容器:1*华夫脆筒。\n返还:1*铁桶。"
            },
            {
                "title": "玉米冰淇淋筒",
                "namespace": "wstqdr:corn_icecreamcone",
                "auxValue": 0,
                "content": "可用冰淇淋搅拌桶制作。\n材料:1*奶桶 + 1~2*鸡蛋 + 1~2*糖 + 1~3*玉米。\n容器:1*华夫脆筒。\n返还:1*铁桶。"
            },
            {
                "title": "奶油冰淇淋筒",
                "namespace": "wstqdr:cream_icecreamcone",
                "auxValue": 0,
                "content": "可用冰淇淋搅拌桶制作。\n材料:1*奶油桶 + 1~2*鸡蛋 + 1~2*糖。\n容器:1*华夫脆筒。\n返还:1*铁桶。"
            },
            {
                "title": "发光浆果冰淇淋筒",
                "namespace": "wstqdr:glow_berry_icecreamcone",
                "auxValue": 0,
                "content": "可用冰淇淋搅拌桶制作。\n材料:1*奶桶 + 1~2*鸡蛋 + 1~2*糖 + 1~3*发光浆果。\n容器:1*华夫脆筒。\n返还:1*铁桶。"
            },
            {
                "title": "草莓冰淇淋筒",
                "namespace": "wstqdr:strawberry_icecreamcone",
                "auxValue": 0,
                "content": "可用冰淇淋搅拌桶制作。\n材料:1*奶桶 + 1~2*鸡蛋 + 1~2*糖 + 1~3*草莓。\n容器:1*华夫脆筒。\n返还:1*铁桶。"
            },
            {
                "title": "甜浆果冰淇淋筒",
                "namespace": "wstqdr:sweet_berry_icecreamcone",
                "auxValue": 0,
                "content": "可用冰淇淋搅拌桶制作。\n材料:1*奶桶 + 1~2*鸡蛋 + 1~2*糖 + 1~3*甜浆果。\n容器:1*华夫脆筒。\n返还:1*铁桶。"
            },
            {
                "title": "番茄冰淇淋筒",
                "namespace": "wstqdr:tomato_icecreamcone",
                "auxValue": 0,
                "content": "可用冰淇淋搅拌桶制作。\n材料:1*奶桶 + 1~2*鸡蛋 + 1~2*糖 + 1~3*番茄。\n容器:1*华夫脆筒。\n返还:1*铁桶。"
            },
            {
                "title": "西瓜冰淇淋筒",
                "namespace": "wstqdr:melon_icecreamcone",
                "auxValue": 0,
                "content": "可用冰淇淋搅拌桶制作。\n材料:1*奶桶 + 1~2*鸡蛋 + 1~2*糖 + 1~3*西瓜片。\n容器:1*华夫脆筒。\n返还:1*铁桶。"
            },
            {
                "title": "闪烁的西瓜冰淇淋筒",
                "namespace": "wstqdr:glistering_melon_icecreamcone",
                "auxValue": 0,
                "content": "可用冰淇淋搅拌桶制作。\n材料:1*奶桶 + 1~2*鸡蛋 + 1~2*糖 + 1~3*闪烁的西瓜片。\n容器:1*华夫脆筒。\n返还:1*铁桶。"
            },
            #冰淇淋杯
            {
                "title": "冰淇淋杯",
                "namespace": "wstqdr:icecreamcup",
                "auxValue": 0,
                "content": "可用冰淇淋搅拌桶制作。\n材料:1*奶桶 + 1~2*鸡蛋 + 1~2*糖。\n容器:1*玻璃瓶。\n返还:1*铁桶。"
            },
            {
                "title": "苹果冰淇淋杯",
                "namespace": "wstqdr:apple_icecreamcup",
                "auxValue": 0,
                "content": "可用冰淇淋搅拌桶制作。\n材料:1*奶桶 + 1~2*鸡蛋 + 1~2*糖 + 1~3*苹果。\n容器:1*玻璃瓶。\n返还:1*铁桶。"
            },
            {
                "title": "香蕉冰淇淋杯",
                "namespace": "wstqdr:banana_icecreamcup",
                "auxValue": 0,
                "content": "可用冰淇淋搅拌桶制作。\n材料:1*奶桶 + 1~2*鸡蛋 + 1~2*糖 + 1~3*香蕉。\n容器:1*玻璃瓶。\n返还:1*铁桶。"
            },
            {
                "title": "蓝莓冰淇淋杯",
                "namespace": "wstqdr:blue_berry_icecreamcup",
                "auxValue": 0,
                "content": "可用冰淇淋搅拌桶制作。\n材料:1*奶桶 + 1~2*鸡蛋 + 1~2*糖 + 1~3*蓝莓。\n容器:1*玻璃瓶。\n返还:1*铁桶。"
            },
            {
                "title": "巧克力冰淇淋杯",
                "namespace": "wstqdr:chocolate_icecreamcup",
                "auxValue": 0,
                "content": "可用冰淇淋搅拌桶制作。\n材料:1*奶桶 + 1~2*鸡蛋 + 1~2*糖 + 1~3*巧克力。\n容器:1*玻璃瓶。\n返还:1*铁桶。"
            },
            {
                "title": "紫颂果冰淇淋杯",
                "namespace": "wstqdr:chorus_fruit_icecreamcup",
                "auxValue": 0,
                "content": "可用冰淇淋搅拌桶制作。\n材料:1*奶桶 + 1~2*鸡蛋 + 1~2*糖 + 1~3*紫颂果。\n容器:1*玻璃瓶。\n返还:1*铁桶。"
            },
            {
                "title": "玉米冰淇淋杯",
                "namespace": "wstqdr:corn_icecreamcup",
                "auxValue": 0,
                "content": "可用冰淇淋搅拌桶制作。\n材料:1*奶桶 + 1~2*鸡蛋 + 1~2*糖 + 1~3*玉米。\n容器:1*玻璃瓶。\n返还:1*铁桶。"
            },
            {
                "title": "奶油冰淇淋杯",
                "namespace": "wstqdr:cream_icecreamcup",
                "auxValue": 0,
                "content": "可用冰淇淋搅拌桶制作。\n材料:1*奶油桶 + 1~2*鸡蛋 + 1~2*糖。\n容器:1*玻璃瓶。\n返还:1*铁桶。"
            },
            {
                "title": "发光浆果冰淇淋杯",
                "namespace": "wstqdr:glow_berry_icecreamcup",
                "auxValue": 0,
                "content": "可用冰淇淋搅拌桶制作。\n材料:1*奶桶 + 1~2*鸡蛋 + 1~2*糖 + 1~3*发光浆果。\n容器:1*玻璃瓶。\n返还:1*铁桶。"
            },
            {
                "title": "草莓冰淇淋杯",
                "namespace": "wstqdr:strawberry_icecreamcup",
                "auxValue": 0,
                "content": "可用冰淇淋搅拌桶制作。\n材料:1*奶桶 + 1~2*鸡蛋 + 1~2*糖 + 1~3*草莓。\n容器:1*玻璃瓶。\n返还:1*铁桶。"
            },
            {
                "title": "甜浆果冰淇淋杯",
                "namespace": "wstqdr:sweet_berry_icecreamcup",
                "auxValue": 0,
                "content": "可用冰淇淋搅拌桶制作。\n材料:1*奶桶 + 1~2*鸡蛋 + 1~2*糖 + 1~3*甜浆果。\n容器:1*玻璃瓶。\n返还:1*铁桶。"
            },
            {
                "title": "番茄冰淇淋杯",
                "namespace": "wstqdr:tomato_icecreamcup",
                "auxValue": 0,
                "content": "可用冰淇淋搅拌桶制作。\n材料:1*奶桶 + 1~2*鸡蛋 + 1~2*糖 + 1~3*番茄。\n容器:1*玻璃瓶。\n返还:1*铁桶。"
            },
            {
                "title": "西瓜冰淇淋杯",
                "namespace": "wstqdr:melon_icecreamcup",
                "auxValue": 0,
                "content": "可用冰淇淋搅拌桶制作。\n材料:1*奶桶 + 1~2*鸡蛋 + 1~2*糖 + 1~3*西瓜片。\n容器:1*玻璃瓶。\n返还:1*铁桶。"
            },
            {
                "title": "闪烁的西瓜冰淇淋杯",
                "namespace": "wstqdr:glistering_melon_icecreamcup",
                "auxValue": 0,
                "content": "可用冰淇淋搅拌桶制作。\n材料:1*奶桶 + 1~2*鸡蛋 + 1~2*糖 + 1~3*闪烁的西瓜片。\n容器:1*玻璃瓶。\n返还:1*铁桶。"
            },
        ],
        "冰棍配方": [
            {
                "title": "老冰棍",
                "namespace": "wstqdr:classic_popsicle",
                "auxValue": 0,
                "content": "可用冰棍模具制作。\n材料:1*糖。"
            },
            {
                "title": "苹果冰棍",
                "namespace": "wstqdr:apple_popsicle",
                "auxValue": 0,
                "content": "可用冰棍模具制作。\n材料:1*苹果。"
            },
            {
                "title": "香蕉冰棍",
                "namespace": "wstqdr:banana_popsicle",
                "auxValue": 0,
                "content": "可用冰棍模具制作。\n材料:1*香蕉。"
            },
            {
                "title": "蓝莓冰棍",
                "namespace": "wstqdr:blue_berry_popsicle",
                "auxValue": 0,
                "content": "可用冰棍模具制作。\n材料:1*蓝莓。"
            },
            {
                "title": "巧克力冰棍",
                "namespace": "wstqdr:chocolate_popsicle",
                "auxValue": 0,
                "content": "可用冰棍模具制作。\n材料:1*巧克力。"
            },
            {
                "title": "紫颂果冰棍",
                "namespace": "wstqdr:chorus_fruit_popsicle",
                "auxValue": 0,
                "content": "可用冰棍模具制作。\n材料:1*紫颂果。"
            },
            {
                "title": "玉米冰棍",
                "namespace": "wstqdr:corn_popsicle",
                "auxValue": 0,
                "content": "可用冰棍模具制作。\n材料:1*玉米。"
            },
            {
                "title": "奶油冰棍",
                "namespace": "wstqdr:cream_popsicle",
                "auxValue": 0,
                "content": "可用冰棍模具制作。\n材料:1*奶油瓶。\n返还:1*玻璃瓶。"
            },
            {
                "title": "发光浆果冰棍",
                "namespace": "wstqdr:glow_berry_popsicle",
                "auxValue": 0,
                "content": "可用冰棍模具制作。\n材料:1*发光浆果。"
            },
            {
                "title": "蜂蜜冰棍",
                "namespace": "wstqdr:honey_popsicle",
                "auxValue": 0,
                "content": "可用冰棍模具制作。\n材料:1*蜂蜜瓶。\n返还:1*玻璃瓶。"
            },
            {
                "title": "草莓冰棍",
                "namespace": "wstqdr:strawberry_popsicle",
                "auxValue": 0,
                "content": "可用冰棍模具制作。\n材料:1*草莓。"
            },
            {
                "title": "甜浆果冰棍",
                "namespace": "wstqdr:sweet_berry_popsicle",
                "auxValue": 0,
                "content": "可用冰棍模具制作。\n材料:1*甜浆果。"
            },
            {
                "title": "番茄冰棍",
                "namespace": "wstqdr:tomato_popsicle",
                "auxValue": 0,
                "content": "可用冰棍模具制作。\n材料:1*番茄。"
            },
            {
                "title": "西瓜棒冰",
                "namespace": "wstqdr:melon_popsicle",
                "auxValue": 0,
                "content": "可用冰棍模具制作。\n材料:1*西瓜片。"
            },
            {
                "title": "闪烁的西瓜棒冰",
                "namespace": "wstqdr:glistering_melon_popsicle",
                "auxValue": 0,
                "content": "可用冰棍模具制作。\n材料:1*闪烁的西瓜片。"
            },
        ],
        "雪泥配方": [
            {
                "title": "雪泥",
                "namespace": "wstqdr:snow_smoothie",
                "auxValue": 0,
                "content": "可在工作台制作。\n材料:1*糖 + 1*雪球 + 1*玻璃瓶。"
            },
            {
                "title": "苹果雪泥",
                "namespace": "wstqdr:apple_smoothie",
                "auxValue": 0,
                "content": "放置雪泥，点击制作。\n材料:1*苹果。"
            },
            {
                "title": "香蕉雪泥",
                "namespace": "wstqdr:banana_smoothie",
                "auxValue": 0,
                "content": "放置雪泥，点击制作。\n材料:1*香蕉。"
            },
            {
                "title": "蓝莓雪泥",
                "namespace": "wstqdr:blue_berry_smoothie",
                "auxValue": 0,
                "content": "放置雪泥，点击制作。\n材料:1*蓝莓。"
            },
            {
                "title": "巧克力雪泥",
                "namespace": "wstqdr:chocolate_smoothie",
                "auxValue": 0,
                "content": "放置雪泥，点击制作。\n材料:1*巧克力。"
            },
            {
                "title": "巧克力胡萝卜雪泥",
                "namespace": "wstqdr:chocolate_carrot_smoothie",
                "auxValue": 0,
                "content": "放置巧克力雪泥，点击制作。\n材料:1*胡萝卜。"
            },
            {
                "title": "紫颂果雪泥",
                "namespace": "wstqdr:chorus_fruit_smoothie",
                "auxValue": 0,
                "content": "放置雪泥，点击制作。\n材料:1*紫颂果。"
            },
            {
                "title": "玉米雪泥",
                "namespace": "wstqdr:corn_smoothie",
                "auxValue": 0,
                "content": "放置雪泥，点击制作。\n材料:1*玉米。"
            },
            {
                "title": "奶油雪泥",
                "namespace": "wstqdr:cream_smoothie",
                "auxValue": 0,
                "content": "放置雪泥，点击制作。\n材料:1*奶油瓶。\n返还:1*玻璃瓶。"
            },
            {
                "title": "发光浆果雪泥",
                "namespace": "wstqdr:glow_berry_smoothie",
                "auxValue": 0,
                "content": "放置雪泥，点击制作。\n材料:1*发光浆果。"
            },
            {
                "title": "葡萄雪泥",
                "namespace": "wstqdr:grape_smoothie",
                "auxValue": 0,
                "content": "放置雪泥，点击制作。\n材料:1*葡萄。"
            },
            {
                "title": "蜂蜜雪泥",
                "namespace": "wstqdr:honey_smoothie",
                "auxValue": 0,
                "content": "放置雪泥，点击制作。\n材料:1*蜂蜜瓶。\n返还:1*玻璃瓶。"
            },
            {
                "title": "草莓雪泥",
                "namespace": "wstqdr:strawberry_smoothie",
                "auxValue": 0,
                "content": "放置雪泥，点击制作。\n材料:1*草莓。"
            },
            {
                "title": "甜浆果雪泥",
                "namespace": "wstqdr:sweet_berry_smoothie",
                "auxValue": 0,
                "content": "放置雪泥，点击制作。\n材料:1*甜浆果。"
            },
            {
                "title": "番茄雪泥",
                "namespace": "wstqdr:tomato_smoothie",
                "auxValue": 0,
                "content": "放置雪泥，点击制作。\n材料:1*番茄。"
            },
            {
                "title": "西瓜雪泥",
                "namespace": "wstqdr:melon_smoothie",
                "auxValue": 0,
                "content": "放置雪泥，点击制作。\n材料:1*西瓜片。"
            },
            {
                "title": "闪烁的西瓜雪泥",
                "namespace": "wstqdr:glistering_melon_smoothie",
                "auxValue": 0,
                "content": "放置雪泥，点击制作。\n材料:1*闪烁的西瓜片。"
            },
        ]
    }
}

#分页按钮排列顺序
orderconfig = {
    "冷藏扩展":[
        "工具",
        "雪泥配方",
        "冰棍配方",
        "冰淇淋配方"
    ]
}