# -*- coding: utf-8 -*-
class NativeScreenManager(object):
	def __init__(self):
		pass

	def RegisterCustomControl(self, nativeData, customControlName, proxyClassName):
		pass

	def UnRegisterCustomControl(self, nativeData, customControlName):
		pass
