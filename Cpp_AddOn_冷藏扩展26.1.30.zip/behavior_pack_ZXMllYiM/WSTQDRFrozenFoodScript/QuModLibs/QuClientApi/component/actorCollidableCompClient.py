# -*- coding: utf-8 -*-
from component.baseComponent import BaseComponent

class ActorCollidableCompClient(BaseComponent):
    def SetActorCollidable(self, isCollidable):
        # type: (int) -> bool
        """
        设置实体是否可碰撞
        """
        pass


