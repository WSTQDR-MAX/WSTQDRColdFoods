# -*- coding: utf-8 -*-
from WSTQDRFrozenFoodScript.QuModLibs.Client import *
from WSTQDRFrozenFoodScript.Script_Config.modConfig import *
CompFactory = clientApi.GetEngineCompFactory()
#取消使用物品
@Listen(Events.ClientItemUseOnEvent)
def OnServerItemUseOnEvent(args):
    entityId = args["entityId"]
    blockName = args["blockName"]
    isSneaking = CompFactory.CreatePlayer(entityId).isSneaking()
    if isSneaking:
        return
    #用物品点击即食3D冷食取消使用物品
    if blockName in PlatedFrozenFoods:
        args["ret"] = True
        args = {"blockName":blockName,"x":args["x"], "y":args["y"], "z":args["z"],"playerId":entityId}
        Call("OnServerPlatedFrozenFoodsEvent",args)
