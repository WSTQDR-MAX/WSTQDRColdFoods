# -*- coding: utf-8 -*-
from WSTQDRFrozenFoodScript.QuModLibs.Server import _loaderSystem
from WSTQDRFrozenFoodScript.Script_Functions.Functions import *
         
#不同口味雪泥的合成(拿着物品点击普通雪泥，得到风味雪泥)
@Listen(Events.ServerItemUseOnEvent)
def OnWSTQDRFrozenFoodSmoothieCraft(args={}):
    entityId = args["entityId"]
    itemDict = args["itemDict"]
    itemName = itemDict["newItemName"]
    blockName = args["blockName"]
    blockPos = (args["x"], args["y"], args["z"])
    dimensionId = args["dimensionId"]
    blockcomp = CompFactory.CreateBlockInfo(entityId)
    statecomp = CompFactory.CreateBlockState(entityId)
    blockstate = statecomp.GetBlockStates(blockPos)
    matched = False
    for SmoothieBlock in SmoothieRecipeDict:
        UseItems = SmoothieRecipeDict[SmoothieBlock].get("UseItems")
        if not UseItems:
            return
        if itemName in UseItems:
            CraftBlock = SmoothieRecipeDict[SmoothieBlock].get("CraftBlock")
            container = SmoothieRecipeDict[SmoothieBlock].get("container")
            SmoothieBlockDict = {"name":SmoothieBlock,"aux":0}
            matched = True
            break
    if not matched:
        return
    Call(entityId,"PlaySwing")
    if not CraftBlock:
        if blockName == "wstqdr:snow_smoothie_block":
            SpawnLessItemsToPlayer(itemDict,entityId)
            if container:
                SpawnItemToPlayer(container,entityId)
            blockcomp.SetBlockNew(blockPos,SmoothieBlockDict,0,dimensionId,False,False)
            SetSameCardinalDirection(blockPos,entityId,dimensionId,blockstate)
            ToAllPlayerPlayParticle(dimensionId,(args["x"] + 0.5, args["y"] + 0.5, args["z"] + 0.5),"wstqdr:craft_smoothie_particle")
            ToAllPlayerPlaySound(dimensionId, blockPos,"bucket.empty_powder_snow",1,random.uniform(0.8,1.0))
    else:
        if blockName == CraftBlock:
            SpawnLessItemsToPlayer(itemDict,entityId)
            if container:
                SpawnItemToPlayer(container,entityId)
            blockcomp.SetBlockNew(blockPos,SmoothieBlockDict,0,dimensionId,False,False)
            SetSameCardinalDirection(blockPos,entityId,dimensionId,blockstate)
            ToAllPlayerPlayParticle(dimensionId,(args["x"] + 0.5, args["y"] + 0.5, args["z"] + 0.5),"wstqdr:craft_smoothie_particle")
            ToAllPlayerPlaySound(dimensionId, blockPos,"bucket.empty_powder_snow",1,random.uniform(0.8,1.0))