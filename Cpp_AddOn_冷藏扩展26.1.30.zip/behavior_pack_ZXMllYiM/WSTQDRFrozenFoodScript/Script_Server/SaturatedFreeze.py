# -*- coding: utf-8 -*-
from WSTQDRFrozenFoodScript.QuModLibs.Server import _loaderSystem
from WSTQDRFrozenFoodScript.Script_Functions.Functions import *

SaturatedFreezeFoods = {
    "wstqdr:suspicious_icecreamcone":{"duration": 30,"amplifier": 0,"showParticles": True,"Maxduration": 180},
    "wstqdr:suspicious_icecreamcup":{"duration": 30,"amplifier": 0,"showParticles": True,"Maxduration": 180}
}

@Listen("PlayerEatFoodServerEvent")
def PlayerEatSaturatedFreezeFoods(args):
    playerId = args["playerId"]
    itemDict = args["itemDict"]
    itemName = itemDict["newItemName"]
    if itemName in SaturatedFreezeFoods:
        duration = SaturatedFreezeFoods[itemName]["duration"]
        amplifier = SaturatedFreezeFoods[itemName]["amplifier"]
        showParticles = SaturatedFreezeFoods[itemName]["showParticles"]
        Maxduration = SaturatedFreezeFoods[itemName]["Maxduration"]
        AllEffects = CompFactory.CreateEffect(playerId).GetAllEffects()
        if AllEffects:
            for Aneffect in AllEffects:
                if Aneffect.get("effectName") == "wstqdr:saturatedfreeze":
                    duration = duration + Aneffect["duration"]
                    if duration > Maxduration:
                        duration = Maxduration
                    break
        CompFactory.CreateEffect(playerId).AddEffectToEntity("wstqdr:saturatedfreeze", duration, amplifier, showParticles)

@Listen("PlayerHungerChangeServerEvent")
def SaturatedFreezeHungerNoChange(args):
    playerId = args["playerId"]
    if CompFactory.CreateEffect(playerId).HasEffect("wstqdr:saturatedfreeze"):
        args["cancel"] = True

    