# -*- coding: utf-8 -*-
from WSTQDRFrozenFoodScript.QuModLibs.Server import _loaderSystem
from WSTQDRFrozenFoodScript.Script_Functions.Functions import *

@Listen(Events.ServerBlockUseEvent)
def OnServerPopsicleMoldUseEvent(args={}):
    playerId = args["playerId"]
    blockName = args["blockName"]
    blockPos = (args["x"], args["y"], args["z"])
    Pos = CompFactory.CreatePos(playerId).GetFootPos()
    dimensionId = args["dimensionId"]
    Playercomp = CompFactory.CreatePlayer(playerId)
    statecomp = CompFactory.CreateBlockState(playerId)
    blockstate = statecomp.GetBlockStates(blockPos)
    if blockName == "wstqdr:popsicle_mold":
        if SetPlayerUsedCD(playerId) is True:
            return
        blockEntityData = CompFactory.CreateBlockEntityData(levelId).GetBlockEntityData(dimensionId, blockPos)
        if not blockEntityData:
            return
        carriedDict = CompFactory.CreateItem(playerId).GetPlayerItem(2, 0, True)
        if carriedDict:#手中拿了物品
            if blockstate["wstqdr:popsicle_type"] == "none":
                if carriedDict["newItemName"] == "minecraft:ice":
                    blockstate["wstqdr:popsicle_type"] = "ice"
                    statecomp.SetBlockStates(blockPos,blockstate,dimensionId)
                    ToAllPlayerPlaySound(dimensionId, blockPos, "armor.equip_leather")
                    SpawnLessItemsToPlayer(carriedDict,playerId)
                    return
            if blockEntityData["output"]:
                if blockstate["wstqdr:popsicle_type"] == "ice":
                    if carriedDict["newItemName"] in  ["minecraft:wooden_axe","minecraft:stone_axe","minecraft:iron_axe","minecraft:golden_axe","minecraft:diamond_axe","minecraft:netherite_axe"]:
                        blockstate["wstqdr:popsicle_type"] = "popsicle"
                        blockstate["wstqdr:popsicle_stage"] = 2
                        statecomp.SetBlockStates(blockPos,blockstate,dimensionId)
                        ToAllPlayerPlayParticle(dimensionId,(args["x"] + 0.5, args["y"] + 0.3, args["z"] + 0.5),"wstqdr:craft_smoothie_particle")
                        ToAllPlayerPlaySound(dimensionId, blockPos,"random.glass",random.uniform(0.8,1.0),random.uniform(0.5,0.6)) 
                    else:
                        CompFactory.CreateGame(playerId).SetOneTipMessage(playerId, "请用斧头雕刻一番...")
                    return
                if blockstate["wstqdr:popsicle_type"] == "popsicle":
                    if carriedDict["newItemName"] == "minecraft:stick":
                        SpawnItemToPlayer(blockEntityData["output"],playerId)
                        SpawnLessItemsToPlayer(carriedDict,playerId)
                        ToAllPlayerPlaySound(dimensionId, blockPos, "armor.equip_leather")
                        if blockstate["wstqdr:popsicle_stage"] == 2:
                            blockstate["wstqdr:popsicle_stage"] = 1
                            statecomp.SetBlockStates(blockPos,blockstate,dimensionId)
                        elif blockstate["wstqdr:popsicle_stage"] == 1:
                            blockstate["wstqdr:popsicle_type"] = "none"
                            blockstate["wstqdr:popsicle_stage"] = 0
                            statecomp.SetBlockStates(blockPos,blockstate,dimensionId)
                            blockEntityData["output"] = None
                    else:
                        CompFactory.CreateGame(playerId).SetOneTipMessage(playerId, "请用木棍串起来...")
#放入冰块,和点击冰块变化
@Listen(Events.ServerItemUseOnEvent)
def OnWSTQDRFrozenFoodPopsicleCraft(args={}):
    entityId = args["entityId"]
    itemDict = args["itemDict"]
    itemName = itemDict["newItemName"]
    blockName = args["blockName"]
    blockPos = (args["x"], args["y"], args["z"])
    dimensionId = args["dimensionId"]
    blockcomp = CompFactory.CreateBlockInfo(entityId)
    statecomp = CompFactory.CreateBlockState(entityId)
    blockstate = statecomp.GetBlockStates(blockPos)
    if blockName != "wstqdr:popsicle_mold":
        return
    blockEntityData = CompFactory.CreateBlockEntityData(levelId).GetBlockEntityData(dimensionId, blockPos)
    if not blockEntityData:
        return
    if blockEntityData["output"]:
        return
    matched = False
    popsicleDict = False
    container = False
    for popsicle in PopsicleMoldRecipeDict:
        UseItems = PopsicleMoldRecipeDict[popsicle].get("UseItems")
        if not UseItems:
            return
        if itemName in UseItems:
            container = PopsicleMoldRecipeDict[popsicle].get("container")
            popsicleDict = {"newItemName": popsicle,"count": 1}
            matched = True
            break
    if not matched:
        return
    if blockstate["wstqdr:popsicle_type"] == "ice":
        blockEntityData["output"] = popsicleDict
        print(blockEntityData["output"])
        SpawnLessItemsToPlayer(itemDict,entityId)
        if container:
            SpawnItemToPlayer(container,entityId)
        ToAllPlayerPlayParticle(dimensionId,(args["x"] + 0.5, args["y"] + 0.3, args["z"] + 0.5),"wstqdr:craft_smoothie_particle")
        ToAllPlayerPlaySound(dimensionId, blockPos,"bucket.empty_powder_snow",1,random.uniform(1.6,2.2))        

@Listen(Events.ServerItemUseOnEvent)
def OnServerIceCreamChurnItemUse(args):
    # 玩家在对方块使用物品之前服务端抛出的事件
    blockName = args["blockName"]
    entityId = args["entityId"]
    Playercomp = CompFactory.CreatePlayer(entityId)
    if blockName == "wstqdr:popsicle_mold":
        if Playercomp.isSneaking():
            return
        args["ret"] = True