# -*- coding: utf-8 -*-
from WSTQDRFrozenFoodScript.QuModLibs.Server import *
from ..Script_Config.guideBookConfig import guidebookconfig,orderconfig
from WSTQDRFrozenFoodScript.Script_Functions.Functions import ResetPlayerUsedCD
CompFactory = serverApi.GetEngineCompFactory()

@Listen(Events.LoadServerAddonScriptsAfter)
def OnWSTQDRFoodS(args={}):#为主包添加冷藏扩展介绍书配置
    WSTQDRFoodSGuideBookConfig = CompFactory.CreateModAttr("wstqdr").GetAttr("wstqdrAddGuideBookConfig")
    WSTQDRFoodSOrderConfig = CompFactory.CreateModAttr("wstqdr").GetAttr("wstqdrAddGuideBookOrderConfig")
    if WSTQDRFoodSGuideBookConfig:
        WSTQDRFoodSGuideBookConfig(guidebookconfig)
    if WSTQDRFoodSOrderConfig:
        WSTQDRFoodSOrderConfig(orderconfig)

breakBlockDict = {
    "wstqdr:icecream_churn"
}

#活塞推动破坏方块
@Listen(Events.PistonActionServerEvent)
def OnPistonActionServerEvent(args={}):
    action = args["action"]
    blockList = args["blockList"]
    dimensionId = args["dimensionId"]
    airblockDict = {'name': 'minecraft:air','aux': 0}
    if action == "retracting":
        args["cancel"] = True
        return
    if not blockList:
        return
    if args["cancel"] == True:
        return
    for Pos in blockList:
        blockPos = tuple(Pos)
        blockDict = CompFactory.CreateBlockInfo(levelId).GetBlockNew(blockPos, dimensionId)
        blockName = blockDict["name"]
        if blockName in breakBlockDict:
            CompFactory.CreateBlockInfo(levelId).SetBlockNew(blockPos, airblockDict, 1, dimensionId)
            args["cancel"] = True
            return    

#玩家加进来初始化CD
@Listen(Events.AddServerPlayerEvent)
def OnAddServerPlayerEvent(args={}):
    playerId = args["id"]
    ResetPlayerUsedCD(playerId)