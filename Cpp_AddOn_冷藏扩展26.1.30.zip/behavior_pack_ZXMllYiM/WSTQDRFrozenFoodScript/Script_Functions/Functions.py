import math
import copy
import random
from WSTQDRFrozenFoodScript.QuModLibs.Server import *
import mod.server.extraServerApi as ServerApi
from WSTQDRFrozenFoodScript.Script_Config.modConfig import *
from WSTQDRFrozenFoodScript.QuModLibs.Server import _loaderSystem
levelId = ServerApi.GetLevelId()
CompFactory = ServerApi.GetEngineCompFactory()

def GetBlockCardinalDirection(x1, z1, x2, z2):
    '''用以获取有方向状态方块的应放置的方向'''
    # 计算两点的角度并返回方向
    dx = x2 - x1
    dz = z2 - z1
    radian = math.atan2(dz, dx)
    angle = math.degrees(radian)
    if -45 < angle < 45:
        cardinal_direction = "east"
    elif 45 < angle < 135:
        cardinal_direction = "south"
    elif 135 < angle < 180 or -180 < angle < -135:
        cardinal_direction = "west"
    else:
        cardinal_direction = "north"
    return cardinal_direction

#设置方块方向函数
def SetBlockCardinalDirection(pos, entityId, dimensionId):
    '''用以设置有方向状态方块的应放置的方向'''
    pX, pY, pZ = CompFactory.CreatePos(entityId).GetFootPos()
    x, y, z = pos
    blockstate = CompFactory.CreateBlockState(entityId).GetBlockStates(pos)
    if blockstate.get("minecraft:cardinal_direction"):
        blockstate["minecraft:cardinal_direction"] = GetBlockCardinalDirection(x, z, pX, pZ)
        CompFactory.CreateBlockState(entityId).SetBlockStates(pos,blockstate,dimensionId)

def SetSameCardinalDirection(pos, entityId, dimensionId, blockstate):
    Blockstate = CompFactory.CreateBlockState(entityId).GetBlockStates(pos)
    if Blockstate.get("minecraft:cardinal_direction"):
        Blockstate["minecraft:cardinal_direction"] = blockstate["minecraft:cardinal_direction"]
        CompFactory.CreateBlockState(entityId).SetBlockStates(pos,Blockstate,dimensionId)   

def MIX_RGB(putintoRGB):
    """
    计算多种RGB混合后的RGB值
    参数:
        putintoRGB: RGB列表
    返回:
        tuple: 混合后的RGB值，格式为 (r, g, b)
    """
    RGBList = copy.deepcopy(putintoRGB)
    total_r = total_g = total_b = total_count =0
    for rgb in RGBList:
        r = rgb.get("r") 
        g = rgb.get("g")
        b = rgb.get("b")   
        total_r += r
        total_g += g
        total_b += b
        total_count += 1
    mix_r = round(total_r / total_count)
    mix_g = round(total_g / total_count)
    mix_b = round(total_b / total_count)
    # 最终约束rgb值在0-255（避免极端情况导致的数值溢出）
    mix_r = max(0, min(255, mix_r))
    mix_g = max(0, min(255, mix_g))
    mix_b = max(0, min(255, mix_b))
    return (mix_r, mix_g, mix_b)

#网易3.5ApI设置实体Property
def SetPropertyValue(entityId,PropertyList):
    "PropertyList是实体属性列表,里面必须是存入的一些(实体属性，值)的元组"
    for Property in PropertyList:
        CompFactory.CreateQueryVariable(entityId).SetPropertyValue(Property[0],Property[1])          

#概率判断
def ProbabilityFunc(Probability):
    '''概率返回布尔值'''
    randomList = []
    for i in range(Probability):
        randomList.append(1)
    for x in range(100 - Probability):
        randomList.append(0)
    extract = random.choice(randomList)
    if extract == 1:
        return True
    else:
        return False

#方块下面坐标    
def IsBelow(pos, neighPos):
        '''
        返回是否为方块下面坐标,布尔值.
        '''
        return pos[0] == neighPos[0] and (pos[1] - 1 == neighPos[1]) and pos[2] == neighPos[2]

def ToAllPlayerPlayParticle(dmId, pos, ParticleName):
    '''
    向所有玩家在世界维度某坐标播放原版或自定义粒子
    '''
    playerList = serverApi.GetPlayerList()
    for playerId in playerList:
        dimensionId = CompFactory.CreateDimension(playerId).GetEntityDimensionId()
        if dimensionId == dmId:
            data = {"ParticleName":ParticleName, "pos":pos}
            Call(playerId,"PlayParticle", data)
            
def ToAllPlayerPlaySound(dmId, pos, soundName, volume = 1, pitch = 1): 
    '''
    向所有玩家在世界维度某坐标播放原版或自定义音效
    '''
    playerList = serverApi.GetPlayerList()
    for playerId in playerList:
        dimensionId = CompFactory.CreateDimension(playerId).GetEntityDimensionId()
        if dimensionId == dmId:
            data = {"soundName": soundName, "pos": pos, "volume":volume, "pitch":pitch}
            Call(playerId,"OnPlaySound", data)  

def ResetPlayerUsedCD(playerId):
    # 重置CD
    CompFactory.CreateModAttr(playerId).SetAttr("WSTQDRPlayerUsedCD", False)
    
def SetPlayerUsedCD(playerId, PlayerUsedCD = 0.2):
    # 设置CD
    cd = CompFactory.CreateModAttr(playerId).GetAttr("WSTQDRPlayerUsedCD")
    if cd is False:
        CompFactory.CreateModAttr(playerId).SetAttr("WSTQDRPlayerUsedCD", True)
        CompFactory.CreateGame(levelId).AddTimer(PlayerUsedCD, ResetPlayerUsedCD, playerId)
        Call(playerId,"PlaySwing")
        return False
    else:
        Call(playerId,"PlaySwing")
        return True
                           
#模拟原版MC物品的使用减少                
def SpawnLessItemsToPlayer(itemDict,playerId):
        '''
        模拟原版MC物品的使用减少;
        itemDict是要减少的自定义的物品字典;
        playerId是玩家的ID.
        '''
        gameType = CompFactory.CreateGame(playerId).GetPlayerGameType(playerId)
        if gameType != 1:
            itemDict["count"] -= 1
            CompFactory.CreateItem(playerId).SetEntityItem(2, itemDict, 0)

#模拟原版生成到背包，背包满了就生成一个物品掉落物
def SpawnItemToPlayer(itemDict,playerId):
    '''
        模拟原版生成到背包，背包满了就生成一个物品掉落物;
        itemDict是要生成的自定义的物品字典;
        playerId是玩家的ID.
        '''
    Pos = CompFactory.CreatePos(playerId).GetPos()
    dimensionId = CompFactory.CreateDimension(playerId).GetEntityDimensionId()
    SpawnItem = CompFactory.CreateItem(playerId).SpawnItemToPlayerInv(itemDict,playerId)
    if not SpawnItem:
        _loaderSystem.CreateEngineItemEntity(itemDict,dimensionId,Pos)