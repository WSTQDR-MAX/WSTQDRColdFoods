# -*- coding: utf-8 -*-
class CustomUIControlProxy(object):
	def __init__(self, customData, customUIControl):
		pass

	def OnCreate(self):
		pass

	def OnDestroy(self):
		pass

	def OnTick(self):
		pass

	def GetCustomUIControl(self):
		pass
