# -*- coding: utf-8 -*-

class ProgressBarUIControl(object):
    def SetValue(self, progress):
        # type: (float) -> None
        """
        设置进度条的进度
        """
        pass

