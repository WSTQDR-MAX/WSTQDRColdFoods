# -*- coding: utf-8 -*-
class GridUIControl(object):
    def SetGridDimension(self, dimension):
        # type: (tuple[int,int]) -> None
        """
        设置Grid控件的大小
        """
        pass

