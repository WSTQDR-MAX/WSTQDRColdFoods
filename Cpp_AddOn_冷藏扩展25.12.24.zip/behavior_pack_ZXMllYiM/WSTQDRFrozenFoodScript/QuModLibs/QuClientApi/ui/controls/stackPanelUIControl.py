# -*- coding: utf-8 -*-


class StackPanelUIControl(object):
    def SetOrientation(self, orientation):
        # type: (str) -> bool
        """
        设置stackPanel的排列方向
        """
        pass

    def GetOrientation(self):
        # type: () -> str
        """
        获取stackPanel的排列方向
        """
        pass

