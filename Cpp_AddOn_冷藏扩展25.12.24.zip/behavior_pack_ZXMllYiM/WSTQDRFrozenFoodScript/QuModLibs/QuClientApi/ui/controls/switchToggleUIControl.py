# -*- coding: utf-8 -*-

class SwitchToggleUIControl(object):
    def SetToggleState(self, is_on, toggle_path='/this_toggle'):
        # type: (bool, bool) -> None
        """
        设置Toggle开关控件的值
        """
        pass

