# -*- coding: utf-8 -*-

from component.baseComponent import BaseComponent

class ChunkSourceCompClient(BaseComponent):
    def GetChunkPosFromBlockPos(self, blockPos):
        """
        通过方块坐标获得该方块所在区块坐标
        """
        pass


