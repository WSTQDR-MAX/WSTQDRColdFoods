# -*- coding: utf-8 -*-


class PosComponentClient(object):
    def GetPos(self):
        # type: () -> tuple[float,float,float]
        """
        获取实体位置
        """
        pass

    def GetFootPos(self):
        # type: () -> tuple[float,float,float]
        """
        获取实体脚所在的位置
        """
        pass


