# -*- coding: utf-8 -*-
from WSTQDRFrozenFoodScript.QuModLibs.Server import _loaderSystem
from WSTQDRFrozenFoodScript.Script_Functions.Functions import *
         
#水流破坏自定义方块掉落
@Listen("BlockDestroyByLiquidServerEvent")
def OnWaterDestoryWSTQDRFrozenBlock(args={}):
    blockName = args["blockName"]
    blockName = "wstqdr:" + blockName
    blockPos = (args["x"], args["y"], args["z"])
    dimensionId = args["dimensionId"]
    if blockName not in CanWaterDestoryWSTQDRFrozenBlocks:
        return
    data = CanWaterDestoryWSTQDRFrozenBlocks.get(blockName)
    if data.get("DropList"):
        DropList = data["DropList"]
        for DropDict in DropList:
            _loaderSystem.CreateEngineItemEntity(DropDict,dimensionId,(args["x"] + random.uniform(0.5,0.75), args["y"] + random.uniform(0.45,0.75), args["z"] + random.uniform(0.5,0.75)))
    if data.get("sound"):
        ToAllPlayerPlaySound(dimensionId, blockPos,data.get("sound"),0.5,random.uniform(0.8,1.0))
    else:
        ToAllPlayerPlaySound(dimensionId, blockPos,"random.pop",0.5,random.uniform(0.8,1.0))

#可放置食物掉落(因支撑方块破坏)
@Listen(Events.BlockNeighborChangedServerEvent)
def OnDropFrozenFoodsNeighborChanged(args={}):
    blockName = args["blockName"]
    matched = False
    for key, rule in CanPlatedItems.items():
        try:
            item_name, block_name = key  
        except ValueError:
            print("规则键 %s 拆包数量错误，已跳过" % key)
            continue
        except TypeError:
            print("规则键 %s 类型错误（不是元组），已跳过" % key)
            continue
        except Exception as e:
            print("处理规则 %s  时发生未知错误：%s ，已跳过" %(key, e))
            continue
        if block_name == blockName:
            matched = True
            break  
    if not matched:
        return
    blockPos = (args["posX"], args["posY"], args["posZ"])
    dimensionId = args["dimensionId"]
    neighborPos = (args["neighborPosX"], args["neighborPosY"], args["neighborPosZ"])
    toBlockName = args["toBlockName"]
    statecomp = CompFactory.CreateBlockState(None)
    blockstate = statecomp.GetBlockStates(blockPos)
    foodstage = blockstate.get("wstqdr:food_stage")
    DropList = CanPlatedItems[key]["DropList"]
    if DropList:
        if type(DropList) == dict:
            if foodstage in DropList:
                DropList = DropList[foodstage]
        elif type(DropList) == list:
            pass
        else:
            return
    if (IsBelow(blockPos, neighborPos)):
        if toBlockName in ["minecraft:air","minecraft:water","minecraft:flowingwater","minecraft:lava","minecraft:flowing_lava"]:
            CompFactory.CreateBlockInfo(levelId).SetBlockNew(blockPos, {"name": "minecraft:air"}, 0, dimensionId)
            for DropDict in DropList:
                _loaderSystem.CreateEngineItemEntity(DropDict,dimensionId,(args["posX"] + random.uniform(0.5,0.75), args["posY"] + random.uniform(0.45,0.75), args["posZ"] + random.uniform(0.5,0.75)))
            ToAllPlayerPlaySound(dimensionId, blockPos,"random.pop",0.5,random.uniform(0.8,1.0))
        
#可放置食物放置
@Listen(Events.ServerItemUseOnEvent)
def OnServerFrozenFoodsPlateOnEvent(args={}):
    face =args["face"]
    entityId =args["entityId"]
    itemDict =args["itemDict"]
    dimensionId =args["dimensionId"]
    uppos =(args["x"],args["y"] + 1, args["z"])
    blockcomp = CompFactory.CreateBlockInfo(entityId)
    upblockdict = blockcomp.GetBlockNew(uppos)
    matched = False
    for key, rule in CanPlatedItems.items():
        try:
            item_name, block_name = key  
        except ValueError:
            print("规则键 %s 拆包数量错误，已跳过" % key)
            continue
        except TypeError:
            print("规则键 %s 类型错误（不是元组），已跳过" % key)
            continue
        except Exception as e:
            print("处理规则 %s  时发生未知错误：%s ，已跳过" %(key, e))
            continue
        if item_name == itemDict["newItemName"]:
            matched = True
            break 
    if not matched:
        return
    is_sneaking = CompFactory.CreatePlayer(entityId).isSneaking()
    if upblockdict["name"] == "minecraft:air" and is_sneaking and face == 1:
        if SetPlayerUsedCD(entityId):
            return
        blockcomp.SetBlockNew(uppos, {"name":block_name,"aux": 0}, 0, dimensionId)
        SetBlockCardinalDirection(uppos, entityId, dimensionId)
        SpawnLessItemsToPlayer(itemDict, entityId)
        if not rule.get("sound"):
            ToAllPlayerPlaySound(dimensionId, (args["x"],args["y"], args["z"]),"dig.stone",1,random.uniform(0.8,1.0))
        else:
            ToAllPlayerPlaySound(dimensionId, (args["x"],args["y"], args["z"]),rule.get("sound")["name"],random.uniform(rule.get("sound")["volume"][0],rule.get("sound")["volume"][1]),random.uniform(rule.get("sound")["pitch"][0],rule.get("sound")["pitch"][1]))

#可放置食物拿起
@Listen(Events.ServerBlockUseEvent)
def OnServerFrozenFoodsHoldEvent(args={}):
    blockName = args["blockName"]
    blockPos = (args["x"], args["y"], args["z"])
    dimensionId = args["dimensionId"]
    playerId = args["playerId"]
    statecomp = CompFactory.CreateBlockState(playerId)
    blockstate = statecomp.GetBlockStates(blockPos)
    airblockDict = {'name': 'minecraft:air','aux': 0}
    matched = False
    for key, rule in CanPlatedItems.items():
        try:
            item_name, block_name = key  
        except ValueError:
            print("规则键 %s 拆包数量错误，已跳过" % key)
            continue
        except TypeError:
            print("规则键 %s 类型错误（不是元组），已跳过" % key)
            continue
        except Exception as e:
            print("处理规则 %s  时发生未知错误：%s ，已跳过" %(key, e))
            continue
        if block_name == blockName:
            matched = True
            break
    if not matched:
        return
    carriedDict = CompFactory.CreateItem(playerId).GetPlayerItem(2, 0, True)
    if carriedDict:#空手才能拿
        return
    if rule.get("CanHold"):
        Call(playerId,"PlaySwing")
        CompFactory.CreateBlockInfo(playerId).SetBlockNew(blockPos, airblockDict,0,dimensionId)
        _loaderSystem.CreateEngineItemEntity({"newItemName": item_name,"count": 1},dimensionId,(args["x"] + random.uniform(0.5,0.75), args["y"] + random.uniform(0.45,0.75), args["z"] + random.uniform(0.5,0.75)))
        ToAllPlayerPlaySound(dimensionId, blockPos,"random.pop",0.5,random.uniform(0.8,1.0))
    Stackable = rule.get("Stackable")
    foodstage = blockstate.get("wstqdr:food_stage")
    if Stackable and foodstage != None:
        if SetPlayerUsedCD(playerId):
            return
        if Stackable["stageMin"] <= foodstage <= Stackable["stageMax"]:
            if foodstage == Stackable["stageMin"]:
                CompFactory.CreateBlockInfo(playerId).SetBlockNew(blockPos,airblockDict,0,dimensionId,False,False)
            else:
                blockstate["wstqdr:food_stage"] -= 1
                statecomp.SetBlockStates(blockPos,blockstate,dimensionId)
            _loaderSystem.CreateEngineItemEntity({"newItemName": item_name, "count": 1}, dimensionId, (args["x"] + random.uniform(0.5,0.75), args["y"] + random.uniform(0.45,0.75), args["z"] + random.uniform(0.5,0.75)))
            ToAllPlayerPlaySound(dimensionId, blockPos,"random.pop",0.5,random.uniform(0.8,1.0))
###可堆叠的放置(比如放下1个立体的冰淇淋方块，用冰淇淋点这个冰淇淋方块，此时这个由1个冰淇淋的模型变成2个冰淇淋模型)
@Listen(Events.ServerItemUseOnEvent)
def OnPlatedStackableFrozenFoods(args={}):
    entityId = args["entityId"]
    itemDict = args["itemDict"]
    itemName = itemDict["newItemName"]
    blockName = args["blockName"]
    blockPos = (args["x"], args["y"], args["z"])
    dimensionId = args["dimensionId"]
    statecomp = CompFactory.CreateBlockState(entityId)
    blockstate = statecomp.GetBlockStates(blockPos)
    airblockDict = {'name': 'minecraft:air','aux': 0}
    matched = False
    for key, rule in CanPlatedItems.items():
        try:
            item_name, block_name = key  
        except ValueError:
            print("规则键 %s 拆包数量错误，已跳过" % key)
            continue
        except TypeError:
            print("规则键 %s 类型错误（不是元组），已跳过" % key)
            continue
        except Exception as e:
            print("处理规则 %s  时发生未知错误：%s ，已跳过" %(key, e))
            continue
        if itemName == item_name and blockName == block_name:
            matched = True
            break 
    if matched:
        Stackable = rule.get("Stackable")
        foodstage = blockstate.get("wstqdr:food_stage")
        if Stackable and foodstage != None:
            if SetPlayerUsedCD(entityId):
                return
            if Stackable["stageMin"] <= foodstage < Stackable["stageMax"]:
                blockstate["wstqdr:food_stage"] += 1
                statecomp.SetBlockStates(blockPos,blockstate,dimensionId)
                SpawnLessItemsToPlayer(itemDict,entityId)
                #放置声音播放
                if not rule.get("sound"):
                    ToAllPlayerPlaySound(dimensionId, blockPos,"armor.equip_leather",1,random.uniform(0.8,1.0))
                else:
                    ToAllPlayerPlaySound(dimensionId, blockPos,rule.get("sound")["name"],random.uniform(rule.get("sound")["volume"][0],rule.get("sound")["volume"][1]),random.uniform(rule.get("sound")["pitch"][0],rule.get("sound")["pitch"][1]))

#可放置食物点击食用
@AllowCall
@Listen(Events.ServerBlockUseEvent)
def OnServerPlatedFrozenFoodsEvent(args={}):
    playerId = args["playerId"]
    blockName = args["blockName"]
    blockPos = (args["x"], args["y"], args["z"])
    Pos = CompFactory.CreatePos(playerId).GetFootPos()
    dimensionId = CompFactory.CreateDimension(playerId).GetEntityDimensionId()
    statecomp = CompFactory.CreateBlockState(playerId)
    airblockDict = {'name': 'minecraft:air','aux': 0}
    if blockName not in PlatedFrozenFoods:
        return
    if SetPlayerUsedCD(playerId) is True:
        return
    blockstate = statecomp.GetBlockStates(blockPos)
    foodstage = blockstate["wstqdr:food_stage"]
    stagehungers = PlatedFrozenFoods.get(blockName).get("stagehungers")
    DropList = PlatedFrozenFoods.get(blockName).get("DropList")
    sound = PlatedFrozenFoods.get(blockName).get("sound")   

    if PlatedFrozenFoods[blockName].get("stageMin", 0) <= blockstate["wstqdr:food_stage"] <= PlatedFrozenFoods[blockName].get("stageMax", 0):
        #吃摆盘食物的状态变化
        if blockstate["wstqdr:food_stage"] < PlatedFrozenFoods[blockName]["stageMax"]:
            blockstate["wstqdr:food_stage"] += 1
            statecomp.SetBlockStates(blockPos,blockstate,dimensionId)
        elif blockstate["wstqdr:food_stage"] == PlatedFrozenFoods[blockName]["stageMax"]:
            CompFactory.CreateBlockInfo(playerId).SetBlockNew(blockPos,airblockDict,0,dimensionId,False,False)
        #判断是否为要掉落残渣(比如玻璃瓶,骨粉这种)的食物
        if DropList:
            if foodstage in DropList:
                DropList = DropList[foodstage]
                for DropDict in DropList:
                    _loaderSystem.CreateEngineItemEntity(DropDict, dimensionId, (args["x"] + random.uniform(0.5,0.75), args["y"] + random.uniform(0.45,0.75), args["z"] + random.uniform(0.5,0.75)))
                ToAllPlayerPlaySound(dimensionId, blockPos,"random.pop",0.5,random.uniform(0.55,0.75))

        #点击食物提供饥饿度和饱和度(如果有饱和度的话)
        hunger = PlatedFrozenFoods[blockName]["hunger"]
        saturation = PlatedFrozenFoods[blockName]["saturation"]
        if stagehungers:
            if foodstage in stagehungers:
                hunger = stagehungers[foodstage]["hunger"]
                saturation = stagehungers[foodstage]["saturation"]
        if saturation:
            Saturation = CompFactory.CreateAttr(playerId).GetAttrValue(5)
            print(Saturation)
            Saturation += saturation
            print(Saturation)
            CompFactory.CreateAttr(playerId).SetAttrValue(5,Saturation)
            print(CompFactory.CreateAttr(playerId).SetAttrValue(5,Saturation))
        playerHunger = CompFactory.CreatePlayer(playerId).GetPlayerHunger() 
        playerHunger += hunger
        CompFactory.CreatePlayer(playerId).SetPlayerHunger(playerHunger)
        #食用声音播放
        if sound:
            stagesounds = sound.get("stagesounds")
            if stagesounds:
                if foodstage in stagesounds:
                    sound = stagesounds[foodstage]
            ToAllPlayerPlaySound(dimensionId, Pos, sound["name"],random.uniform(sound["volume"][0],sound["volume"][1]),random.uniform(sound["pitch"][0],sound["pitch"][1]))
        else:
            ToAllPlayerPlaySound(dimensionId, Pos, "random.burp")
        #根据字典信息添加状态(如果有的话)
        if PlatedFrozenFoods[blockName].get("Effect"):
            for index, Effect in enumerate(PlatedFrozenFoods[blockName]["Effect"]):
                effectName = PlatedFrozenFoods[blockName]["Effect"][index]["effectName"]
                duration = PlatedFrozenFoods[blockName]["Effect"][index]["duration"]
                amplifier = PlatedFrozenFoods[blockName]["Effect"][index]["amplifier"]
                showParticles = PlatedFrozenFoods[blockName]["Effect"][index]["showParticles"]
                Maxduration = PlatedFrozenFoods[blockName]["Effect"][index]["Maxduration"]
                Probability = PlatedFrozenFoods[blockName]["Effect"][index].get("Probability")
                if not Maxduration:
                    Maxduration = 480
                AllEffects = CompFactory.CreateEffect(playerId).GetAllEffects()
                if AllEffects:
                    for Aneffect in AllEffects:
                        if Aneffect.get("effectName") == effectName:
                            duration = duration + Aneffect["duration"]
                            if duration > Maxduration:
                                duration = Maxduration
                            break
                if Probability:
                    if not ProbabilityFunc(Probability):
                        return
                CompFactory.CreateEffect(playerId).AddEffectToEntity(effectName, duration, amplifier, showParticles)        
         