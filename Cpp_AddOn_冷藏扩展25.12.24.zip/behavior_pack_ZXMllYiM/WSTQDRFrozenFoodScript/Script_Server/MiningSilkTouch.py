# -*- coding: utf-8 -*-
from WSTQDRFrozenFoodScript.Script_Functions.Functions import *

# 防止精准采集挖掘掉落
@Listen(Events.ServerPlayerTryDestroyBlockEvent)
def OnTryDestroyBlock(args={}):
    blockName = args["fullName"]
    if blockName not in NoMiningSilkTouchDict:
        return
    dimensionId = args["dimensionId"]
    blockPos = (args["x"], args["y"], args["z"])
    playerId = args["playerId"]
    blockStates = CompFactory.CreateBlockState(playerId).GetBlockStates(blockPos,dimensionId)
    handItemDict = CompFactory.CreateItem(playerId).GetPlayerItem(serverApi.GetMinecraftEnum().ItemPosType.CARRIED, 0, True)
    if handItemDict is None:
        return
    enchantData = handItemDict.get("enchantData")
    if not enchantData:
        return
    for enchant in enchantData:
        if enchant[0] == 16:
            gameType = CompFactory.CreateGame(playerId).GetPlayerGameType(playerId)
            if gameType == 1:
                return
            CompFactory.CreateExtraData(playerId).SetExtraData("NoMiningSilkWouchblockStates", blockStates)

# 防止精准采集挖掘掉落
@Listen(Events.DestroyBlockEvent)
def OnDestroyBlock(args={}):
    blockName = args["fullName"]
    if blockName not in NoMiningSilkTouchDict:
        return
    dimensionId = args["dimensionId"]
    blockPos = (args["x"], args["y"], args["z"])
    playerId = args["playerId"]
    blockDict = {"name":blockName, "aux": 0}
    handItemDict = CompFactory.CreateItem(playerId).GetPlayerItem(serverApi.GetMinecraftEnum().ItemPosType.CARRIED, 0, True)
    if handItemDict is None:
        return
    enchantData = handItemDict.get("enchantData")
    if not enchantData:
        return
    for enchant in enchantData:
        if enchant[0] == 16:
            gameType = CompFactory.CreateGame(playerId).GetPlayerGameType(playerId)
            if gameType == 1:
                return
            CompFactory.CreateBlockInfo(playerId).SetBlockNew(blockPos, blockDict, 0, dimensionId)
            blockStates = CompFactory.CreateExtraData(playerId).GetExtraData("NoMiningSilkWouchblockStates")
            CompFactory.CreateBlockState(playerId).SetBlockStates(blockPos, blockStates, dimensionId)
            dropItemList = args["dropEntityIds"]
            for Id in dropItemList:
                DestroyEntity(Id)
            airblockDict = {'name': 'minecraft:air','aux': 0}
            CompFactory.CreateBlockInfo(playerId).SetBlockNew(blockPos, airblockDict, 1, dimensionId)
            
