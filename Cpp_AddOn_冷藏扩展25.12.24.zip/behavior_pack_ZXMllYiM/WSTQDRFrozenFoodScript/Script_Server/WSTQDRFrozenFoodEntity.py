# -*- coding: utf-8 -*-
from WSTQDRFrozenFoodScript.Script_Functions.Functions import *

UndeadEntity = {
    "wstqdr:icecreamchurn_fill"
}

for entity in UndeadEntity:
    serverApi.AddEntityTickEventWhiteList(entity)

@Listen("HealthChangeBeforeServerEvent")
def OnHealthChangeBeforeUndeadEntity(args={}):
    # 防止一些实体被Kill
    entityId = args["entityId"]
    identifier =CompFactory.CreateEngineType(entityId).GetEngineTypeStr()
    if identifier in UndeadEntity:
        args["cancel"] = True

@Listen("WillTeleportToServerEvent")
def OnWillTeleportToServerUndeadEntity(args={}):
    # 阻止一些实体被传送走。
    entityId = args["entityId"]
    identifier = CompFactory.CreateEngineType(entityId).GetEngineTypeStr()
    if identifier in UndeadEntity:
        args["cancel"] = True

@Listen("WillAddEffectServerEvent")
def OnWillAddEffectServerUndeadEntity(args={}):
    # 阻止一些实体被给予药水效果。
    entityId = args["entityId"]
    identifier = CompFactory.CreateEngineType(entityId).GetEngineTypeStr()
    if identifier in UndeadEntity:
        args["cancel"] = True

#防止锁仇恨在一些实体上
@Listen("OnGroundServerEvent")
def onServerAttackTarget(args={}):
    id = args["id"]
    targetId = CompFactory.CreateAction(id).GetAttackTarget()
    entityIdentifier = CompFactory.CreateEngineType(targetId).GetEngineTypeStr()
    if entityIdentifier in UndeadEntity:
        CompFactory.CreateAction(id).ResetAttackTarget()
